import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RevealDirective } from '../../directives/reveal.directive';

interface UniverseProject {
  title: string;
  overview: string;
  role: string;
  tech: string[];
  impact: string;
  link: string;
  color: string;
  size: number; // relative orb size
  pos: { x: number; y: number }; // % position within stage
}

@Component({
  selector: 'app-project-universe',
  standalone: true,
  imports: [CommonModule, RevealDirective],
  template: `
    <section class="pu">
      <span class="pu-eyebrow" appReveal>/Project Universe</span>
      <h2 class="pu-title" appReveal [revealDelay]="60">Things I've Shipped</h2>

      <div class="pu-stage">
        <div
          *ngFor="let p of projects"
          class="orb"
          [style.--c]="p.color"
          [style.width.px]="p.size"
          [style.height.px]="p.size"
          [style.left.%]="p.pos.x"
          [style.top.%]="p.pos.y"
          [class.active]="active === p"
          (click)="open(p)">
          <span class="orb-label">{{ p.title }}</span>
        </div>
      </div>

      <div class="pu-detail" *ngIf="active" (click)="close()">
        <div class="detail-card" (click)="$event.stopPropagation()">
          <button class="close-btn" (click)="close()">×</button>
          <h3 [style.color]="active.color">{{ active.title }}</h3>

          <div class="detail-row"><span class="d-h">Overview</span><p>{{ active.overview }}</p></div>
          <div class="detail-row"><span class="d-h">Role</span><p>{{ active.role }}</p></div>
          <div class="detail-row">
            <span class="d-h">Tech</span>
            <div class="tags"><span class="tag" *ngFor="let t of active.tech">{{ t }}</span></div>
          </div>
          <div class="detail-row"><span class="d-h">Impact</span><p>{{ active.impact }}</p></div>

          <a [href]="active.link" target="_blank" class="visit-link">Visit project ↗</a>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .pu {
      width: 100%; height: 100%;
      background: radial-gradient(ellipse at 50% 30%, #1a1a2e 0%, #0a0a12 70%);
      color: #f5f3ee;
      display: flex; flex-direction: column; align-items: center;
      padding: 56px 24px 24px; position: relative; overflow: hidden;
    }
    .pu-eyebrow { font-family: 'Space Mono', monospace; font-size: 11px; letter-spacing: 0.15em; color: #ff5e1a; text-transform: uppercase; margin-bottom: 10px; }
    .pu-title { font-family: 'DM Serif Display', serif; font-size: clamp(1.8rem, 3.6vw, 2.8rem); margin-bottom: 24px; }

    .pu-stage { position: relative; width: 100%; max-width: 1000px; flex: 1; }

    .orb {
      position: absolute;
      border-radius: 50%;
      background: radial-gradient(circle at 32% 28%, color-mix(in srgb, var(--c) 75%, white), var(--c) 70%);
      box-shadow: 0 0 32px color-mix(in srgb, var(--c) 50%, transparent), inset -8px -8px 20px rgba(0,0,0,0.25);
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      animation: float 6s ease-in-out infinite;
      transition: transform 0.3s ease;
    }
    .orb:hover { transform: scale(1.08); }
    .orb.active { transform: scale(1.12); box-shadow: 0 0 48px color-mix(in srgb, var(--c) 70%, transparent); }
    .orb-label {
      font-size: 12px; font-weight: 600; text-align: center; padding: 0 10px;
      color: rgba(0,0,0,0.75); text-shadow: 0 1px 2px rgba(255,255,255,0.2);
    }
    @keyframes float {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-14px); }
    }
    .orb:nth-child(2n) { animation-duration: 7.5s; animation-delay: -1.5s; }
    .orb:nth-child(3n) { animation-duration: 5.2s; animation-delay: -3s; }

    .pu-detail {
      position: fixed; inset: 0; z-index: 80;
      background: rgba(8,8,12,0.78); backdrop-filter: blur(6px);
      display: flex; align-items: center; justify-content: center;
      animation: fadeIn 0.3s ease;
    }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .detail-card {
      background: #16161c; border: 1px solid rgba(255,255,255,0.08);
      border-radius: 16px; padding: 36px; max-width: 460px; width: 90%;
      position: relative;
      animation: pop 0.35s cubic-bezier(0.16,1,0.3,1);
    }
    @keyframes pop { from { transform: scale(0.92); opacity: 0; } to { transform: scale(1); opacity: 1; } }
    .close-btn {
      position: absolute; top: 16px; right: 16px;
      width: 32px; height: 32px; border-radius: 50%; border: none;
      background: rgba(255,255,255,0.08); color: #f5f3ee; font-size: 18px;
      cursor: pointer;
    }
    .detail-card h3 { font-family: 'DM Serif Display', serif; font-size: 1.6rem; margin-bottom: 20px; }
    .detail-row { margin-bottom: 16px; }
    .d-h { display: block; font-size: 10px; letter-spacing: 0.1em; text-transform: uppercase; color: rgba(245,243,238,0.45); margin-bottom: 4px; font-family: 'Space Mono', monospace; }
    .detail-row p { font-size: 14px; line-height: 1.6; color: rgba(245,243,238,0.85); }
    .tags { display: flex; flex-wrap: wrap; gap: 6px; }
    .tag { font-size: 11px; padding: 3px 10px; border-radius: 100px; border: 1px solid rgba(255,255,255,0.15); }
    .visit-link {
      display: inline-block; margin-top: 8px; font-size: 13px; font-weight: 600;
      color: #ff5e1a;
    }

    @media (max-width: 700px) {
      .pu-stage { transform: scale(0.8); }
    }
  `]
})
export class ProjectUniverseComponent {
  active: UniverseProject | null = null;

  projects: UniverseProject[] = [
    {
      title: 'Fiinco', color: '#4facfe', size: 150, pos: { x: 8, y: 18 },
      link: 'https://client.digisuites.com/#/login',
      overview: 'Fintech client platform for settlements and account management.',
      role: 'Lead frontend engineer — Angular architecture, state management, UI.',
      tech: ['Angular', 'RxJS', 'NgRx', 'SCSS'],
      impact: 'Core platform used daily by client operations teams.'
    },
    {
      title: 'Fiinco Admin', color: '#667eea', size: 120, pos: { x: 32, y: 52 },
      link: 'https://client.digisuites.com/admin/#/dashboard',
      overview: 'Internal admin dashboard for managing Fiinco accounts, permissions, and settlement flows.',
      role: 'Built permission-driven views and reporting dashboards.',
      tech: ['Angular', 'Angular Material', 'Highcharts'],
      impact: 'Cut manual reconciliation time for the ops team.'
    },
    {
      title: 'Payoflex', color: '#a18cd1', size: 135, pos: { x: 58, y: 16 },
      link: 'https://client.digisuites.com/payoflexadmin/#/auth/login',
      overview: 'Payment gateway admin platform handling transaction monitoring and merchant management.',
      role: 'Frontend development, payment gateway integrations.',
      tech: ['Angular', 'Payment Gateways', 'REST APIs'],
      impact: 'Streamlined merchant onboarding and transaction visibility.'
    },
    {
      title: 'TradingView', color: '#fcb69f', size: 145, pos: { x: 76, y: 56 },
      link: 'https://web.onepip.app/tradingview/#/login',
      overview: 'Real-time trading interface with live charting and order management.',
      role: 'Built real-time UI with WebSocket data feeds and Highcharts.',
      tech: ['Angular', 'WebSockets', 'Highcharts'],
      impact: 'Sub-second price updates across live trading sessions.'
    },
    {
      title: '.NET WebForms / XRM', color: '#43e97b', size: 110, pos: { x: 18, y: 78 },
      link: 'https://xrmqa.acrocorp.com/XRM_QA/',
      overview: 'Legacy enterprise system maintained and extended on .NET Webforms.',
      role: 'Maintenance, feature development, SQL Server backend work.',
      tech: ['.NET Webforms', 'C#', 'SQL Server'],
      impact: 'Kept a critical legacy system stable and extensible.'
    },
    {
      title: 'BPPS', color: '#20bf6b', size: 100, pos: { x: 46, y: 82 },
      link: 'javascript:void(0)',
      overview: 'Bharat Bill Payment System integration for utility bill payments.',
      role: 'Built Node.js services for BBPS integration.',
      tech: ['Node.js', 'Express', 'BBPS'],
      impact: 'Enabled bill-payment workflows across partner channels.'
    },
    {
      title: 'CarCare', color: '#61dafb', size: 95, pos: { x: 88, y: 22 },
      link: 'javascript:void(0)',
      overview: 'Vehicle service tracking app for scheduling and history.',
      role: 'Built the React frontend end to end.',
      tech: ['React', 'JavaScript', 'CSS'],
      impact: 'First production React build — shipped solo.'
    }
  ];

  open(p: UniverseProject) { this.active = p; }
  close() { this.active = null; }
}
