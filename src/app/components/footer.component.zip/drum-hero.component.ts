import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RevealDirective } from '../../directives/reveal.directive';

@Component({
  selector: 'app-drum-hero',
  standalone: true,
  imports: [CommonModule, RevealDirective],
  template: `
    <section class="dh">
      <div class="dh-bg-grid"></div>

      <div class="dh-inner">
        <div class="dh-avatar" appReveal>
          <img src="assets/images/avatar-bust.jpg" alt="Shivam Kumar Divaker" onerror="this.style.display='none'">
          <span class="ring"></span>
        </div>

        <h1 class="dh-headline" appReveal [revealDelay]="80">
          BUILDING SCALABLE<br>DIGITAL PRODUCTS
        </h1>

        <p class="dh-sub" appReveal [revealDelay]="160">
          Software Engineer focused on Angular, React, .NET and Node ecosystems.
        </p>

        <div class="dh-metrics" appReveal [revealDelay]="240">
          <div class="metric"><span class="num">4+</span><span class="lbl">Years</span></div>
          <div class="metric"><span class="num">15+</span><span class="lbl">Projects</span></div>
          <div class="metric"><span class="num">8+</span><span class="lbl">Technologies</span></div>
        </div>

        <div class="dh-actions" appReveal [revealDelay]="320">
          <a href="javascript:void(0)" class="btn btn-primary" (click)="scrollToProjects()">View Work</a>
          <a href="assets/resume/Shivam_Kumar_Divaker.pdf" download class="btn btn-ghost">Resume</a>
          <a href="javascript:void(0)" class="btn btn-ghost" (click)="scrollToContact()">Book Intro</a>
        </div>
      </div>

      <div class="dh-scroll-hint" appReveal [revealDelay]="420">
        <span>Scroll</span>
        <span class="chevron">↓</span>
      </div>
    </section>
  `,
  styles: [`
    .dh {
      width: 100%; height: 100%;
      background: #0a0a0a;
      color: #f5f3ee;
      display: flex; align-items: center; justify-content: center;
      position: relative; overflow: hidden;
    }
    .dh-bg-grid {
      position: absolute; inset: 0;
      background-image:
        linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px);
      background-size: 64px 64px;
      mask-image: radial-gradient(ellipse at center, black 0%, transparent 75%);
    }
    .dh-inner {
      position: relative; z-index: 1;
      display: flex; flex-direction: column; align-items: center;
      text-align: center; max-width: 880px; padding: 0 24px;
    }

    .dh-avatar { position: relative; width: 116px; height: 116px; margin-bottom: 28px; }
    .dh-avatar img {
      width: 100%; height: 100%; border-radius: 50%; object-fit: cover;
      border: 1px solid rgba(255,255,255,0.12);
    }
    .ring {
      position: absolute; inset: -10px;
      border: 1px solid rgba(255,94,26,0.4);
      border-radius: 50%;
      animation: spin 14s linear infinite;
    }
    .ring::before {
      content: ''; position: absolute; top: -2px; left: 50%;
      width: 5px; height: 5px; background: #ff5e1a; border-radius: 50%;
      transform: translateX(-50%);
    }
    @keyframes spin { to { transform: rotate(360deg); } }

    .dh-headline {
      font-family: 'Inter', sans-serif;
      font-weight: 800;
      font-size: clamp(2.4rem, 6.4vw, 5.4rem);
      line-height: 1.04;
      letter-spacing: -0.02em;
      margin-bottom: 20px;
    }
    .dh-sub {
      font-size: clamp(15px, 1.6vw, 18px);
      color: rgba(245,243,238,0.65);
      max-width: 560px;
      line-height: 1.6;
      margin-bottom: 40px;
    }

    .dh-metrics { display: flex; gap: 48px; margin-bottom: 44px; }
    .metric { display: flex; flex-direction: column; align-items: center; }
    .num { font-family: 'DM Serif Display', serif; font-size: 2.1rem; color: #ff5e1a; }
    .lbl { font-size: 11px; color: rgba(245,243,238,0.5); letter-spacing: 0.08em; text-transform: uppercase; margin-top: 4px; }

    .dh-actions { display: flex; gap: 14px; flex-wrap: wrap; justify-content: center; }
    .btn {
      padding: 14px 30px; border-radius: 100px; font-size: 14px; font-weight: 500;
      transition: transform 0.25s ease, background 0.25s ease, border-color 0.25s ease;
    }
    .btn-primary { background: #ff5e1a; color: #0a0a0a; }
    .btn-primary:hover { transform: translateY(-2px); background: #ff7438; }
    .btn-ghost { border: 1.5px solid rgba(255,255,255,0.2); color: #f5f3ee; }
    .btn-ghost:hover { border-color: rgba(255,255,255,0.5); transform: translateY(-2px); }

    .dh-scroll-hint {
      position: absolute; bottom: 32px; left: 50%; transform: translateX(-50%);
      display: flex; flex-direction: column; align-items: center; gap: 6px;
      font-family: 'Space Mono', monospace; font-size: 10px;
      letter-spacing: 0.15em; text-transform: uppercase;
      color: rgba(245,243,238,0.4);
    }
    .chevron { animation: bob 2s ease-in-out infinite; }
    @keyframes bob { 0%,100%{transform:translateY(0)} 50%{transform:translateY(6px)} }

    @media (max-width: 768px) {
      .dh-metrics { gap: 28px; }
      .dh-actions { flex-direction: column; width: 100%; }
      .btn { width: 100%; text-align: center; }
    }
  `]
})
export class DrumHeroComponent {
  scrollToProjects() {
    document.dispatchEvent(new CustomEvent('roller-goto', { detail: 'projects' }));
  }
  scrollToContact() {
    document.dispatchEvent(new CustomEvent('roller-goto', { detail: 'contact' }));
  }
}
