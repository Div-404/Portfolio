import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RevealDirective } from '../../directives/reveal.directive';

interface MindsetCard {
  title: string;
  desc: string;
  icon: string;
}

@Component({
  selector: 'app-engineering-mindset',
  standalone: true,
  imports: [CommonModule, RevealDirective],
  template: `
    <section class="em">
      <span class="em-eyebrow" appReveal>/How I Think</span>
      <h2 class="em-title" appReveal [revealDelay]="60">Engineering Mindset</h2>

      <div class="em-grid">
        <div class="em-card" *ngFor="let c of cards; let i = index" appReveal [revealDelay]="120 + i * 80">
          <span class="em-icon">{{ c.icon }}</span>
          <h3>{{ c.title }}</h3>
          <p>{{ c.desc }}</p>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .em {
      width: 100%; height: 100%;
      background: #f0ece3; color: #111;
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      padding: 40px 24px;
    }
    .em-eyebrow { font-family: 'Space Mono', monospace; font-size: 11px; letter-spacing: 0.15em; color: #ff5e1a; text-transform: uppercase; margin-bottom: 10px; }
    .em-title { font-family: 'DM Serif Display', serif; font-size: clamp(1.8rem, 3.6vw, 2.8rem); margin-bottom: 48px; }

    .em-grid {
      display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px;
      max-width: 1100px; width: 100%;
    }
    .em-card {
      background: #fff; border: 1px solid rgba(0,0,0,0.08); border-radius: 16px;
      padding: 32px 24px; transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .em-card:hover { transform: translateY(-6px); box-shadow: 0 16px 40px rgba(0,0,0,0.08); }
    .em-icon { font-size: 28px; display: block; margin-bottom: 16px; }
    .em-card h3 { font-family: 'DM Serif Display', serif; font-size: 1.2rem; margin-bottom: 10px; }
    .em-card p { font-size: 13.5px; color: #555; line-height: 1.65; }

    @media (max-width: 900px) {
      .em-grid { grid-template-columns: 1fr 1fr; }
    }
    @media (max-width: 560px) {
      .em-grid { grid-template-columns: 1fr; }
    }
  `]
})
export class EngineeringMindsetComponent {
  cards: MindsetCard[] = [
    {
      title: 'Scalability', icon: '◫',
      desc: 'I design for the load that hasn\u2019t arrived yet — lazy loading, code splitting, and module boundaries that let a product grow without a rewrite.'
    },
    {
      title: 'Architecture', icon: '⌬',
      desc: 'Component-driven, MVVM where it fits, microservice boundaries where they earn their complexity — structure should make the next feature easier, not harder.'
    },
    {
      title: 'Performance', icon: '⚡',
      desc: 'Real-time interfaces over WebSockets, sub-second chart updates, and a habit of profiling before optimizing — performance is a feature, not an afterthought.'
    },
    {
      title: 'Developer Experience', icon: '◎',
      desc: 'Clear types, documented components, and code a teammate can extend at 2am without pinging me — DX compounds the same way tech debt does, just in the other direction.'
    }
  ];
}
