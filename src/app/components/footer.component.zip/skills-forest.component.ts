import {
  Component, ElementRef, OnInit, OnDestroy, ViewChild, NgZone, AfterViewInit
} from '@angular/core';
import { CommonModule } from '@angular/common';
import * as THREE from 'three';
import { RevealDirective } from '../../directives/reveal.directive';

interface SkillCategory {
  name: string;
  accent: number;     // hex for the tree's foliage + light color
  skills: string[];
}

/**
 * app-skills-forest — Section 4: Skills Forest.
 *
 * Six lit, labeled Christmas trees (one per skill category), each built from
 * stacked cone layers — wide at the BOTTOM, narrowing toward the TOP — with
 * a ring of swaying string lights per layer. Clicking a tree expands a panel
 * listing every skill in that category.
 */
@Component({
  selector: 'app-skills-forest',
  standalone: true,
  imports: [CommonModule, RevealDirective],
  template: `
    <section class="sf">
      <span class="sf-eyebrow" appReveal>/Skills Forest</span>
      <h2 class="sf-title" appReveal [revealDelay]="60">What I Build With</h2>

      <div class="sf-stage">
        <canvas #canvas class="sf-canvas"></canvas>
        <div class="sf-labels">
          <button
            *ngFor="let c of categories; let i = index"
            class="tree-label"
            [style.left.%]="labelPositions[i]"
            [class.active]="activeIndex === i"
            (click)="toggle(i)">
            {{ c.name }}
          </button>
        </div>
      </div>

      <div class="sf-panel" *ngIf="activeIndex !== null">
        <span class="panel-h">{{ categories[activeIndex!].name }}</span>
        <div class="tags">
          <span class="tag" *ngFor="let s of categories[activeIndex!].skills">{{ s }}</span>
        </div>
      </div>

      <p class="sf-hint" *ngIf="activeIndex === null" appReveal [revealDelay]="160">
        Click a tree to see what's inside
      </p>
    </section>
  `,
  styles: [`
    .sf {
      width: 100%; height: 100%;
      background: linear-gradient(180deg, #0a0e1a 0%, #111827 55%, #0a0e1a 100%);
      color: #f5f3ee;
      display: flex; flex-direction: column; align-items: center;
      padding: 48px 24px 24px; overflow: hidden;
    }
    .sf-eyebrow { font-family: 'Space Mono', monospace; font-size: 11px; letter-spacing: 0.15em; color: #ff5e1a; text-transform: uppercase; margin-bottom: 10px; }
    .sf-title { font-family: 'DM Serif Display', serif; font-size: clamp(1.8rem, 3.6vw, 2.8rem); margin-bottom: 16px; }

    .sf-stage { position: relative; width: 100%; max-width: 1100px; flex: 1; min-height: 0; }
    .sf-canvas { position: absolute; inset: 0; width: 100%; height: 100%; display: block; }

    .sf-labels {
      position: absolute; bottom: 6%; left: 0; right: 0; height: 1px;
    }
    .tree-label {
      position: absolute; bottom: 0; transform: translateX(-50%);
      background: rgba(10,10,16,0.6); border: 1px solid rgba(255,255,255,0.15);
      color: rgba(245,243,238,0.85); font-size: 11px; font-weight: 600;
      padding: 6px 14px; border-radius: 100px; cursor: pointer;
      backdrop-filter: blur(4px);
      transition: border-color 0.25s, background 0.25s, transform 0.25s;
      white-space: nowrap;
    }
    .tree-label:hover { border-color: #ff5e1a; transform: translateX(-50%) translateY(-3px); }
    .tree-label.active { background: #ff5e1a; color: #0a0a0a; border-color: #ff5e1a; }

    .sf-panel {
      margin-top: 18px; max-width: 700px; width: 100%;
      background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1);
      border-radius: 12px; padding: 18px 22px;
      animation: slideUp 0.35s cubic-bezier(0.16,1,0.3,1);
    }
    @keyframes slideUp { from { opacity:0; transform: translateY(12px);} to {opacity:1; transform:translateY(0);} }
    .panel-h { display: block; font-size: 11px; letter-spacing: 0.1em; text-transform: uppercase; color: #ff5e1a; margin-bottom: 10px; font-family: 'Space Mono', monospace; }
    .tags { display: flex; flex-wrap: wrap; gap: 7px; }
    .tag { font-size: 12px; padding: 4px 12px; border-radius: 100px; border: 1px solid rgba(255,255,255,0.15); }

    .sf-hint { margin-top: 18px; font-size: 11px; color: rgba(245,243,238,0.35); font-family: 'Space Mono', monospace; }

    @media (max-width: 768px) {
      .tree-label { font-size: 9.5px; padding: 4px 10px; }
    }
  `]
})
export class SkillsForestComponent implements AfterViewInit, OnDestroy {
  @ViewChild('canvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;

  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private host!: HTMLElement;
  private lights: { mesh: THREE.Mesh; string?: THREE.Mesh; swaySeed: number }[] = [];
  private frameId = 0;
  private resizeObserver?: ResizeObserver;

  activeIndex: number | null = null;
  labelPositions = [9, 25, 41, 59, 75, 91]; // % across stage, matches tree x positions

  readonly LAYERS = 4;

  categories: SkillCategory[] = [
    { name: 'Languages', accent: 0xf7df1e, skills: ['JavaScript (ES6+)', 'TypeScript', 'C#', 'Java', 'HTML5', 'CSS3', 'SCSS'] },
    { name: 'Frontend', accent: 0xdd0031, skills: ['Angular (v12–v19)', 'RxJS', 'NgRx', 'Angular Material', 'Highcharts', 'Bootstrap', 'React'] },
    { name: 'Backend', accent: 0x339933, skills: ['Node.js', 'Express.js', 'REST APIs', 'Webhook Integration', '.NET Webforms', 'ASP.NET', 'SQL Server'] },
    { name: 'Architecture', accent: 0xa18cd1, skills: ['Microservices', 'Lazy Loading', 'Code Splitting', 'Component-Driven', 'MVVM', 'Module Federation'] },
    { name: 'Integrations', accent: 0xfcb69f, skills: ['BBPS', 'Payment Gateways', 'Slack API', 'AI Bots', 'WebSockets'] },
    { name: 'Tools', accent: 0xffd93d, skills: ['Git', 'GitHub', 'Postman'] },
  ];

  constructor(private zone: NgZone) {}

  ngAfterViewInit() {
    this.initScene();
    this.buildForest();
    this.zone.runOutsideAngular(() => this.animate());
    this.resizeObserver = new ResizeObserver(() => this.onResize());
    this.resizeObserver.observe(this.host);
  }

  toggle(i: number) {
    this.activeIndex = this.activeIndex === i ? null : i;
  }

  private initScene() {
    const canvas = this.canvasRef.nativeElement;
    this.host = canvas.parentElement as HTMLElement;
    const width = this.host.clientWidth || 800;
    const height = this.host.clientHeight || 500;

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    this.camera.position.set(0, 1.3, 11);
    this.camera.lookAt(0, 0.8, 0);

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setClearColor(0x000000, 0);

    const ambient = new THREE.AmbientLight(0x4a5a7a, 0.65);
    this.scene.add(ambient);
    const sun = new THREE.DirectionalLight(0xffe9c4, 0.55); // "Sunlight Glow"
    sun.position.set(3, 9, 5);
    this.scene.add(sun);

    const groundGeo = new THREE.PlaneGeometry(40, 10);
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x0d1320, roughness: 0.9 });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -1.9;
    this.scene.add(ground);

    window.addEventListener('resize', this.onResize);
  }

  private buildForest() {
    const count = this.categories.length;
    const spacing = 3.0;
    const totalWidth = (count - 1) * spacing;
    const startX = -totalWidth / 2;
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4a3220, roughness: 0.9 });

    this.categories.forEach((cat, i) => {
      const tree = new THREE.Group();
      tree.position.x = startX + i * spacing;

      // Trunk
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, 0.5, 8), trunkMat);
      trunk.position.y = -1.6;
      tree.add(trunk);

      // Foliage: WIDE AT BOTTOM, NARROW AT TOP — stacked cone layers
      const treeBaseY = -1.35;
      const treeTotalHeight = 3.4;
      const layerH = treeTotalHeight / this.LAYERS;
      const foliageMat = new THREE.MeshStandardMaterial({
        color: cat.accent, roughness: 0.6, metalness: 0.05, flatShading: true,
        transparent: true, opacity: 0.18 // subtle "leaves" tint, lets lights read clearly
      });
      const darkFoliageMat = new THREE.MeshStandardMaterial({ color: 0x0d3a26, roughness: 0.8, flatShading: true });

      for (let layerIdx = 0; layerIdx < this.LAYERS; layerIdx++) {
        const t = layerIdx / (this.LAYERS - 1);
        const radius = 1.05 - t * 0.78;
        const coneHeight = layerH * 1.35;
        const layerY = treeBaseY + layerIdx * layerH * 0.78 + coneHeight / 2;

        const cone = new THREE.Mesh(new THREE.ConeGeometry(radius, coneHeight, 9), darkFoliageMat);
        cone.position.y = layerY;
        tree.add(cone);

        // Light ring (category accent color)
        const lightCount = 7 - layerIdx;
        const ringY = layerY - coneHeight / 2 + 0.16;
        const ringRadius = radius * 0.92;

        for (let li = 0; li < lightCount; li++) {
          const angle = (li / lightCount) * Math.PI * 2 + layerIdx * 0.5;
          const lx = Math.cos(angle) * ringRadius;
          const lz = Math.sin(angle) * ringRadius;

          const string = new THREE.Mesh(
            new THREE.CylinderGeometry(0.004, 0.004, 0.12, 4),
            new THREE.MeshBasicMaterial({ color: 0x2a2a2a })
          );
          string.position.set(lx, ringY + 0.06, lz);
          tree.add(string);

          const bulb = new THREE.Mesh(
            new THREE.SphereGeometry(0.045, 8, 8),
            new THREE.MeshStandardMaterial({
              color: cat.accent, emissive: cat.accent, emissiveIntensity: 1.1, roughness: 0.3
            })
          );
          bulb.position.set(lx, ringY, lz);
          tree.add(bulb);

          this.lights.push({ mesh: bulb, string, swaySeed: Math.random() * Math.PI * 2 });
        }
      }

      // Star
      const star = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.14, 0),
        new THREE.MeshStandardMaterial({ color: cat.accent, emissive: cat.accent, emissiveIntensity: 1.3 })
      );
      star.position.y = treeBaseY + (this.LAYERS - 1) * layerH * 0.78 + (layerH * 1.35) / 2 + 0.3;
      tree.add(star);

      this.scene.add(tree);
    });
  }

  private onResize = () => {
    if (!this.host) return;
    const width = this.host.clientWidth;
    const height = this.host.clientHeight;
    if (!width || !height) return;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private animate = () => {
    this.frameId = requestAnimationFrame(this.animate);
    const t = performance.now() * 0.001;

    // Wind: lights + strings sway
    for (const l of this.lights) {
      const sway = Math.sin(t * 1.5 + l.swaySeed) * 0.22;
      if (l.string) l.string.rotation.z = sway;
      const mat = l.mesh.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = 0.8 + Math.sin(t * 3 + l.swaySeed) * 0.35;
    }

    this.renderer.render(this.scene, this.camera);
  };

  ngOnDestroy() {
    cancelAnimationFrame(this.frameId);
    this.resizeObserver?.disconnect();
    window.removeEventListener('resize', this.onResize);
    this.renderer?.dispose();
  }
}
