import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-experience',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div>
      <h2 class="section-title">Experience</h2>
      <div class="exp-grid">
        <div class="exp-card glass" *ngFor="let exp of experiences; let i = index"
             [style.transition-delay]="i * 0.06 + 's'">
          <h3>{{ exp.company }}</h3>
          <div class="role">{{ exp.role }} | {{ exp.period }}</div>
          <p>{{ exp.description }}</p>
          <div class="tech-tags">
            <span class="tech-tag" *ngFor="let t of exp.tags">{{ t }}</span>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .exp-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      gap: 20px;
    }
    .exp-card {
      padding: 28px;
      transition: all 0.3s cubic-bezier(0.22,1,0.36,1);
    }
    .exp-card:hover { border-color: var(--accent-cyan); transform: translateY(-5px); }
    .exp-card h3 { font-size: 1.4rem; margin-bottom: 4px; color: var(--text-primary); }
    .role { font-size: 13px; color: var(--accent-cyan); font-family: var(--font-mono); margin-bottom: 12px; }
    .exp-card p { font-size: 14px; color: var(--text-secondary); line-height: 1.7; margin-bottom: 14px; }
    .tech-tags { display: flex; flex-wrap: wrap; gap: 6px; }
    .tech-tag {
      padding: 3px 10px;
      border-radius: 100px;
      background: rgba(0,212,255,0.08);
      border: 1px solid rgba(0,212,255,0.15);
      font-size: 11px;
      color: var(--accent-cyan);
      font-family: var(--font-mono);
    }
  `]
})
export class ExperienceComponent {
  experiences = [
    { company: 'FinTech Corp', role: 'Senior Software Engineer', period: '2024 - Present', description: 'Architected real-time reconciliation engine processing 2M+ daily events. Led migration from monolith to event-driven microservices with Kafka and CQRS.', tags: ['Go', 'Kafka', 'PostgreSQL', 'AWS'] },
    { company: 'HealthTech Inc', role: 'Full Stack Engineer', period: '2023 - 2024', description: 'Built HIPAA-compliant data platform unifying 50+ clinics. Designed FHIR API layer and real-time sync pipeline handling 1M+ records daily.', tags: ['TypeScript', 'Node.js', 'GraphQL', 'Docker'] },
    { company: 'E-Commerce Co', role: 'Software Engineer', period: '2022 - 2023', description: 'Developed microservices architecture for order management. Implemented event sourcing with Kafka and CQRS pattern, reducing order latency by 60%.', tags: ['Go', 'gRPC', 'Redis', 'Kubernetes'] },
    { company: 'StartupXYZ', role: 'Junior Developer', period: '2021 - 2022', description: 'Built analytics dashboard with custom D3.js visualizations serving 10K+ daily users. Owned frontend architecture and design system.', tags: ['React', 'D3.js', 'TypeScript', 'Tailwind'] },
  ];
}
