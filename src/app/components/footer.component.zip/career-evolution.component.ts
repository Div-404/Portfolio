import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RevealDirective } from '../../directives/reveal.directive';

interface TimelineStop {
  label: string;
  years: string;
  projects: string[];
  stack: string[];
  color: string;
}

@Component({
  selector: 'app-career-evolution',
  standalone: true,
  imports: [CommonModule, RevealDirective],
  template: `
    <section class="ce">
      <span class="ce-eyebrow" appReveal>/Career Evolution</span>
      <h2 class="ce-title" appReveal [revealDelay]="60">From .NET Webforms to System Design</h2>

      <div class="ce-line-wrap" appReveal [revealDelay]="140">
        <div class="ce-line"></div>
        <div class="ce-stops">
          <div
            *ngFor="let s of stops; let i = index"
            class="ce-stop"
            [class.expanded]="expandedIndex === i"
            [style.--accent]="s.color"
            (click)="toggle(i)">
            <span class="stop-dot"></span>
            <span class="stop-label">{{ s.label }}</span>
            <span class="stop-years">{{ s.years }}</span>

            <div class="stop-panel" [class.open]="expandedIndex === i">
              <div class="panel-block">
                <span class="panel-h">Projects</span>
                <ul><li *ngFor="let p of s.projects">{{ p }}</li></ul>
              </div>
              <div class="panel-block">
                <span class="panel-h">Stack</span>
                <div class="tags">
                  <span class="tag" *ngFor="let t of s.stack">{{ t }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <p class="ce-hint" appReveal [revealDelay]="200">Click any stop to expand</p>
    </section>
  `,
  styles: [`
    .ce {
      width: 100%; height: 100%;
      background: #111;
      color: #f5f3ee;
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      padding: 40px 24px;
    }
    .ce-eyebrow {
      font-family: 'Space Mono', monospace; font-size: 11px; letter-spacing: 0.15em;
      color: #ff5e1a; text-transform: uppercase; margin-bottom: 12px;
    }
    .ce-title {
      font-family: 'DM Serif Display', serif;
      font-size: clamp(1.8rem, 3.6vw, 2.8rem);
      margin-bottom: 56px; text-align: center;
    }

    .ce-line-wrap { position: relative; width: 100%; max-width: 1100px; }
    .ce-line {
      position: absolute; top: 7px; left: 0; right: 0; height: 1px;
      background: rgba(255,255,255,0.15);
    }
    .ce-stops {
      display: flex; justify-content: space-between; gap: 8px;
      flex-wrap: wrap;
    }

    .ce-stop {
      position: relative;
      display: flex; flex-direction: column; align-items: center;
      cursor: pointer; flex: 1; min-width: 130px;
    }
    .stop-dot {
      width: 14px; height: 14px; border-radius: 50%;
      background: #111; border: 2px solid var(--accent);
      margin-bottom: 14px; z-index: 1;
      transition: transform 0.3s ease, background 0.3s ease;
    }
    .ce-stop:hover .stop-dot, .ce-stop.expanded .stop-dot {
      background: var(--accent); transform: scale(1.3);
    }
    .stop-label { font-size: 13px; font-weight: 600; text-align: center; }
    .stop-years { font-size: 10px; color: rgba(245,243,238,0.45); font-family: 'Space Mono', monospace; margin-top: 2px; }

    .stop-panel {
      max-height: 0; overflow: hidden; opacity: 0;
      transition: max-height 0.5s cubic-bezier(0.16,1,0.3,1), opacity 0.4s ease, margin-top 0.4s ease;
      width: 220px; margin-top: 0;
      text-align: left;
    }
    .stop-panel.open { max-height: 280px; opacity: 1; margin-top: 18px; }
    .panel-block { margin-bottom: 14px; }
    .panel-h {
      display: block; font-size: 10px; letter-spacing: 0.1em; text-transform: uppercase;
      color: var(--accent); margin-bottom: 6px; font-family: 'Space Mono', monospace;
    }
    .panel-block ul { list-style: none; padding: 0; margin: 0; }
    .panel-block li {
      font-size: 12.5px; color: rgba(245,243,238,0.75); padding: 3px 0;
      border-bottom: 1px solid rgba(255,255,255,0.06);
    }
    .tags { display: flex; flex-wrap: wrap; gap: 6px; }
    .tag {
      font-size: 10.5px; padding: 3px 9px; border-radius: 100px;
      border: 1px solid rgba(255,255,255,0.15); color: rgba(245,243,238,0.8);
    }

    .ce-hint {
      margin-top: 48px; font-size: 11px; color: rgba(245,243,238,0.35);
      font-family: 'Space Mono', monospace; letter-spacing: 0.05em;
    }

    @media (max-width: 900px) {
      .ce-line { display: none; }
      .ce-stops { flex-direction: column; align-items: stretch; gap: 24px; }
      .ce-stop { flex-direction: row; align-items: flex-start; gap: 12px; min-width: 0; }
      .stop-dot { margin-bottom: 0; margin-top: 4px; flex-shrink: 0; }
      .stop-panel { width: 100%; }
    }
  `]
})
export class CareerEvolutionComponent {
  expandedIndex: number | null = 0;

  stops: TimelineStop[] = [
    {
      label: '.NET Webforms', years: 'Early', color: '#512bd4',
      projects: ['.NET WebForms / XRM platform'],
      stack: ['.NET Webforms', 'C#', 'SQL Server']
    },
    {
      label: 'ASP.NET', years: '', color: '#8c4d9e',
      projects: ['Internal admin tooling', 'Reporting dashboards'],
      stack: ['ASP.NET', 'C#', 'SQL Server']
    },
    {
      label: 'Angular', years: 'v12 → v19', color: '#dd0031',
      projects: ['Fiinco', 'Fiinco Admin', 'Payoflex', 'TradingView'],
      stack: ['Angular', 'RxJS', 'NgRx', 'Angular Material', 'Highcharts']
    },
    {
      label: 'React', years: '', color: '#61dafb',
      projects: ['CarCare'],
      stack: ['React', 'JavaScript', 'CSS']
    },
    {
      label: 'Node', years: '', color: '#339933',
      projects: ['BPPS', 'Webhook & payment integrations'],
      stack: ['Node.js', 'Express.js', 'REST APIs', 'WebSockets']
    },
    {
      label: 'System Design', years: 'Current', color: '#a18cd1',
      projects: ['Microservice boundaries', 'Module Federation experiments'],
      stack: ['Microservices', 'Lazy Loading', 'Component-Driven', 'MVVM']
    }
  ];

  toggle(i: number) {
    this.expandedIndex = this.expandedIndex === i ? null : i;
  }
}
