import { Directive, ElementRef, Input } from '@angular/core';

/** Marks an element as a panel inside <app-roller-scroll>. */
@Directive({
  selector: '[rollerPanel]',
  standalone: true
})
export class RollerPanelDirective {
  @Input() rollerPanel = '';
  constructor(public elementRef: ElementRef<HTMLElement>) {}
}
