import {
  Component, ElementRef, OnDestroy, ViewChild, NgZone, AfterViewInit, Input
} from '@angular/core';
import { CommonModule } from '@angular/common';
import * as THREE from 'three';
import { GLTFLoader, GLTF } from 'three/examples/jsm/loaders/GLTFLoader.js';

/**
 * app-avatar-3d — loads the real Blue_Suit_Man.glb model via GLTFLoader
 * and renders it as a slowly-rotating, lit centerpiece.
 *
 * Scale/centering notes (measured directly from the glTF's POSITION
 * accessor min/max, not guessed):
 *   raw bounding box: X 0.333, Y 0.180, Z 1.000, centered at origin.
 *   The model's single node carries a baked rotation quaternion
 *   [0.7071, 0, 0, 0.7071] = 90° around X, which is what stands the
 *   figure upright (raw Z-depth becomes world-Y height once that node
 *   transform is applied). GLTFLoader preserves this automatically
 *   when you add `gltf.scene` directly — no manual rotation needed.
 *   After that rotation, world-space height ≈ 1.0 unit, so it needs a
 *   deliberate scale multiplier to read as a human-sized figure at the
 *   camera distances used elsewhere in this app (constructor-supplied
 *   `targetHeight` controls this explicitly rather than a magic number).
 */
@Component({
  selector: 'app-avatar-3d',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="avatar3d-host">
      <canvas #canvas class="avatar3d-canvas"></canvas>
      <div class="avatar3d-loading" *ngIf="isLoading">
        <div class="spinner"></div>
        <span *ngIf="loadProgress > 0">{{ loadProgress }}%</span>
      </div>
      <div class="avatar3d-fallback" *ngIf="loadFailed">
        <img src="assets/images/avatar-bust.jpg" alt="Shivam Kumar Divaker" onerror="this.style.display='none'">
      </div>
    </div>
  `,
  styles: [`
    .avatar3d-host { position: relative; width: 100%; height: 100%; }
    .avatar3d-canvas { width: 100%; height: 100%; display: block; }
    .avatar3d-loading {
      position: absolute; inset: 0; display: flex; flex-direction: column;
      align-items: center; justify-content: center; gap: 10px;
    }
    .spinner {
      width: 28px; height: 28px; border-radius: 50%;
      border: 2px solid rgba(255,255,255,0.15); border-top-color: #ff5e1a;
      animation: spin 0.9s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    .avatar3d-loading span {
      font-family: 'Space Mono', monospace; font-size: 11px; color: rgba(245,243,238,0.5);
    }
    .avatar3d-fallback {
      position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
    }
    .avatar3d-fallback img {
      width: 70%; height: 70%; object-fit: cover; border-radius: 50%;
      border: 1px solid rgba(255,255,255,0.15);
    }
  `]
})
export class Avatar3dComponent implements AfterViewInit, OnDestroy {
  @ViewChild('canvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;

  /** Desired on-screen height of the figure, in Three.js world units,
   *  at the camera distance chosen below. Tune this one number rather
   *  than guessing scale factors on the raw mesh. */
  @Input() targetHeight = 2.6;

  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private model?: THREE.Object3D;
  private host!: HTMLElement;
  private frameId = 0;
  private resizeObserver?: ResizeObserver;
  loadFailed = false;
  isLoading = true;
  loadProgress = 0;

  // Measured directly from the glTF POSITION accessor (see class doc).
  private readonly RAW_BOUNDS = { x: 0.3336627930402756, y: 0.17960459738969803, z: 0.9999918043613434 };

  constructor(private zone: NgZone) {}

  ngAfterViewInit() {
    this.initScene();
    this.loadModel();
    this.zone.runOutsideAngular(() => this.animate());
    this.resizeObserver = new ResizeObserver(() => this.onResize());
    this.resizeObserver.observe(this.host);
  }

  private initScene() {
    const canvas = this.canvasRef.nativeElement;
    this.host = canvas.parentElement as HTMLElement;
    const width = this.host.clientWidth || 400;
    const height = this.host.clientHeight || 500;

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(32, width / height, 0.1, 50);
    this.camera.position.set(0, this.targetHeight * 0.42, this.targetHeight * 2.3);
    this.camera.lookAt(0, this.targetHeight * 0.42, 0);

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setClearColor(0x000000, 0);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    // Lighting tuned for a suited figure — key + warm fill + soft ambient
    const key = new THREE.DirectionalLight(0xfff3e8, 2.0);
    key.position.set(2.5, 4, 3);
    this.scene.add(key);

    const fill = new THREE.DirectionalLight(0xff8a3d, 0.7);
    fill.position.set(-3, 1, -2);
    this.scene.add(fill);

    const ambient = new THREE.AmbientLight(0xffffff, 0.6);
    this.scene.add(ambient);

    window.addEventListener('resize', this.onResize);
  }

  private loadModel() {
    const loader = new GLTFLoader();
    loader.load(
      'assets/models/blue-suit-man.glb',
      (gltf: GLTF) => {
        const root = gltf.scene;

        // The node's own baked rotation (90° about X) is preserved by
        // GLTFLoader automatically since we add gltf.scene as-is — do
        // NOT re-apply rotation here, that would double-rotate it.

        // Scale: raw post-rotation height ≈ RAW_BOUNDS.z (the axis that
        // becomes "up" after the node's X rotation) ≈ 1.0 unit.
        const rawHeight = this.RAW_BOUNDS.z;
        const scale = this.targetHeight / rawHeight;
        root.scale.setScalar(scale);

        // Re-center: bounding box was already ~centered at origin in
        // raw mesh space, but compute the actual world-space box after
        // scaling to be exact rather than assuming.
        const box = new THREE.Box3().setFromObject(root);
        const center = box.getCenter(new THREE.Vector3());
        root.position.x -= center.x;
        root.position.z -= center.z;
        // Sit the feet on y=0 rather than centering vertically
        root.position.y -= box.min.y;

        root.traverse((obj) => {
          if ((obj as THREE.Mesh).isMesh) {
            const mesh = obj as THREE.Mesh;
            mesh.castShadow = true;
            mesh.receiveShadow = true;
            const mat = mesh.material as THREE.MeshStandardMaterial;
            if (mat && 'map' in mat && mat.map) {
              mat.map.colorSpace = THREE.SRGBColorSpace;
            }
          }
        });

        this.model = root;
        this.scene.add(root);
        this.isLoading = false;
      },
      (progressEvent: ProgressEvent) => {
        // Real download progress from GLTFLoader's underlying XHR/fetch —
        // lengthComputable can be false if the server doesn't send
        // Content-Length, in which case we just show the spinner alone.
        if (progressEvent.lengthComputable && progressEvent.total > 0) {
          this.loadProgress = Math.round((progressEvent.loaded / progressEvent.total) * 100);
        }
      },
      (err) => {
        console.error('avatar-3d: failed to load blue-suit-man.glb', err);
        this.loadFailed = true;
        this.isLoading = false;
      }
    );
  }

  private onResize = () => {
    if (!this.host) return;
    const width = this.host.clientWidth;
    const height = this.host.clientHeight;
    if (!width || !height) return;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private animate = () => {
    this.frameId = requestAnimationFrame(this.animate);
    if (this.model) {
      const t = performance.now() * 0.0004;
      this.model.rotation.y = Math.sin(t) * 0.5; // gentle turn, not a full spin
    }
    this.renderer.render(this.scene, this.camera);
  };

  ngOnDestroy() {
    cancelAnimationFrame(this.frameId);
    this.resizeObserver?.disconnect();
    window.removeEventListener('resize', this.onResize);
    this.renderer?.dispose();
  }
}
