import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RevealDirective } from '../../directives/reveal.directive';

@Component({
  selector: 'app-drum-contact',
  standalone: true,
  imports: [CommonModule, RevealDirective],
  template: `
    <section class="dc">
      <h2 class="dc-title" appReveal>Let's Build<br>Something</h2>

      <div class="dc-actions" appReveal [revealDelay]="120">
        <a href="https://linkedin.com/in/shivam-kumar-divakar-30b567137" target="_blank" class="dc-btn">LinkedIn</a>
        <a href="assets/resume/Shivam_Kumar_Divaker.pdf" download class="dc-btn">Resume</a>
        <a href="https://github.com/Div-404" target="_blank" class="dc-btn">GitHub</a>
        <a href="mailto:arjundivaker8@gmail.com" class="dc-btn dc-btn-primary">Email</a>
      </div>

      <span class="dc-footer-note" appReveal [revealDelay]="220">© {{ year }} Shivam Kumar Divaker</span>
    </section>
  `,
  styles: [`
    .dc {
      width: 100%; height: 100%;
      background: #0a0a0a; color: #f5f3ee;
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      text-align: center; padding: 40px 24px;
    }
    .dc-title {
      font-family: 'DM Serif Display', serif;
      font-size: clamp(2.6rem, 7vw, 5.6rem);
      line-height: 1.05; letter-spacing: -0.02em; margin-bottom: 48px;
    }
    .dc-actions { display: flex; gap: 14px; flex-wrap: wrap; justify-content: center; }
    .dc-btn {
      padding: 15px 32px; border-radius: 100px; font-size: 14px; font-weight: 500;
      border: 1.5px solid rgba(255,255,255,0.2); color: #f5f3ee;
      transition: transform 0.25s ease, border-color 0.25s ease, background 0.25s ease;
    }
    .dc-btn:hover { border-color: rgba(255,255,255,0.5); transform: translateY(-2px); }
    .dc-btn-primary { background: #ff5e1a; border-color: #ff5e1a; color: #0a0a0a; }
    .dc-btn-primary:hover { background: #ff7438; }

    .dc-footer-note {
      margin-top: 56px; font-size: 11px; color: rgba(245,243,238,0.35);
      font-family: 'Space Mono', monospace; letter-spacing: 0.05em;
    }

    @media (max-width: 600px) {
      .dc-actions { flex-direction: column; width: 100%; max-width: 280px; }
      .dc-btn { width: 100%; }
    }
  `]
})
export class DrumContactComponent {
  year = new Date().getFullYear();
}
