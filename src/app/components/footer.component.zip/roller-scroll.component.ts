import {
  Component, ElementRef, ViewChild, AfterViewInit, OnDestroy, HostListener,
  ContentChildren, QueryList, AfterContentInit
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RollerPanelDirective } from './roller-panel.directive';

/**
 * app-roller-scroll — "Roller Drum" snap-scroll shell.
 *
 * Wraps N direct children marked with [rollerPanel]. Only one panel is
 * fully visible at a time; wheel/touch/keyboard input advances to the
 * next/previous panel with a depth (translateZ/scale) + fade transition,
 * instead of normal document scroll. A dot-nav on the right lets you jump
 * directly to any panel.
 */
@Component({
  selector: 'app-roller-scroll',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="roller-viewport" #viewport>
      <div class="roller-track" [style.transform]="trackTransform">
        <ng-content></ng-content>
      </div>
    </div>

    <nav class="roller-dots" aria-label="Section navigation">
      <button
        *ngFor="let p of panels; let i = index"
        class="dot"
        [class.active]="i === activeIndex"
        [attr.aria-label]="'Go to section ' + (i + 1)"
        (click)="goTo(i)">
        <span class="dot-label">{{ panelLabels[i] }}</span>
      </button>
    </nav>

    <div class="roller-progress">
      <div class="progress-fill" [style.height.%]="progressPercent"></div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      position: relative;
      width: 100%;
      height: 100vh;
      overflow: hidden;
    }

    .roller-viewport {
      width: 100%;
      height: 100%;
      overflow: hidden;
      perspective: 1400px;
    }

    .roller-track {
      width: 100%;
      transition: transform 0.95s cubic-bezier(0.16, 1, 0.3, 1);
      will-change: transform;
    }

    ::ng-deep .roller-track > * {
      display: block;
      width: 100%;
      height: 100vh;
      position: relative;
      transition: opacity 0.85s cubic-bezier(0.16,1,0.3,1), transform 0.85s cubic-bezier(0.16,1,0.3,1), filter 0.85s ease;
    }
    ::ng-deep .roller-track > .roller-active {
      opacity: 1;
      transform: scale(1) translateZ(0);
      filter: blur(0);
    }
    ::ng-deep .roller-track > .roller-prev {
      opacity: 0.35;
      transform: scale(0.94) translateZ(-80px);
      filter: blur(1px);
    }
    ::ng-deep .roller-track > .roller-next {
      opacity: 0.35;
      transform: scale(0.94) translateZ(-80px);
      filter: blur(1px);
    }
    ::ng-deep .roller-track > .roller-far {
      opacity: 0;
      transform: scale(0.88) translateZ(-160px);
      filter: blur(2px);
    }
    @media (prefers-reduced-motion: reduce) {
      ::ng-deep .roller-track > * { transition: opacity 0.3s ease; transform: none !important; filter: none !important; }
    }

    .roller-dots {
      position: fixed;
      right: 28px;
      top: 50%;
      transform: translateY(-50%);
      display: flex;
      flex-direction: column;
      gap: 18px;
      z-index: 50;
    }
    .dot {
      width: 9px; height: 9px;
      border-radius: 50%;
      background: rgba(255,255,255,0.25);
      border: none;
      cursor: pointer;
      position: relative;
      padding: 0;
      transition: background 0.3s, transform 0.3s;
    }
    .dot:hover { background: rgba(255,255,255,0.55); transform: scale(1.2); }
    .dot.active { background: #ff5e1a; transform: scale(1.35); }
    .dot-label {
      position: absolute;
      right: 22px; top: 50%;
      transform: translateY(-50%);
      font-family: 'Space Mono', monospace;
      font-size: 10px;
      letter-spacing: 0.08em;
      color: rgba(255,255,255,0.8);
      white-space: nowrap;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.25s;
      background: rgba(10,10,10,0.7);
      padding: 4px 10px;
      border-radius: 4px;
    }
    .dot:hover .dot-label, .dot.active .dot-label { opacity: 1; }

    .roller-progress {
      position: fixed;
      left: 28px; top: 50%;
      transform: translateY(-50%);
      width: 2px; height: 140px;
      background: rgba(255,255,255,0.15);
      z-index: 50;
      border-radius: 2px;
      overflow: hidden;
    }
    .progress-fill {
      width: 100%;
      background: #ff5e1a;
      transition: height 0.6s cubic-bezier(0.16, 1, 0.3, 1);
      border-radius: 2px;
    }

    @media (max-width: 768px) {
      .roller-dots { right: 14px; gap: 14px; }
      .dot-label { display: none; }
      .roller-progress { left: 14px; height: 100px; }
    }
  `]
})
export class RollerScrollComponent implements AfterViewInit, AfterContentInit, OnDestroy {
  @ViewChild('viewport', { static: true }) viewportRef!: ElementRef<HTMLDivElement>;
  @ContentChildren(RollerPanelDirective) panelDirectives!: QueryList<RollerPanelDirective>;

  panels: HTMLElement[] = [];
  panelLabels: string[] = [];
  activeIndex = 0;
  trackTransform = 'translateY(0)';

  private isAnimating = false;
  private readonly ANIM_LOCK_MS = 950;
  private touchStartY = 0;
  private wheelAccum = 0;
  private wheelResetTimer: any;

  ngAfterContentInit() {
    this.panels = this.panelDirectives.map(p => p.elementRef.nativeElement);
    this.panelLabels = this.panelDirectives.map(p => p.rollerPanel || '');
  }

  ngAfterViewInit() {
    // Disable native scroll on the body while this shell is active
    document.body.style.overflow = 'hidden';
    this.updateTransform();
    document.addEventListener('roller-goto', this.onGotoEvent as EventListener);
  }

  ngOnDestroy() {
    document.body.style.overflow = '';
    clearTimeout(this.wheelResetTimer);
    document.removeEventListener('roller-goto', this.onGotoEvent as EventListener);
  }

  private onGotoEvent = (e: CustomEvent) => {
    const label = e.detail as string;
    const idx = this.panelLabels.findIndex(l => l.toLowerCase() === label.toLowerCase());
    if (idx !== -1) this.goTo(idx);
  };

  get progressPercent(): number {
    if (this.panels.length <= 1) return 0;
    return (this.activeIndex / (this.panels.length - 1)) * 100;
  }

  goTo(index: number) {
    if (this.isAnimating || index === this.activeIndex) return;
    if (index < 0 || index >= this.panels.length) return;

    this.isAnimating = true;
    this.activeIndex = index;
    this.updateTransform();

    setTimeout(() => { this.isAnimating = false; }, this.ANIM_LOCK_MS);
  }

  private updateTransform() {
    this.trackTransform = `translateY(-${this.activeIndex * 100}vh)`;

    // Apply depth/fade state to each panel based on distance from active,
    // so transitions feel like depth movement, not a flat slide.
    this.panels.forEach((panel, i) => {
      const dist = i - this.activeIndex;
      panel.classList.remove('roller-active', 'roller-prev', 'roller-next', 'roller-far');
      if (dist === 0) panel.classList.add('roller-active');
      else if (dist === -1) panel.classList.add('roller-prev');
      else if (dist === 1) panel.classList.add('roller-next');
      else panel.classList.add('roller-far');
    });
  }

  @HostListener('window:wheel', ['$event'])
  onWheel(e: WheelEvent) {
    e.preventDefault();
    if (this.isAnimating) return;

    // Accumulate small trackpad deltas so a deliberate flick triggers one
    // step, not several — keeps the "roller" feeling deliberate.
    this.wheelAccum += e.deltaY;
    clearTimeout(this.wheelResetTimer);
    this.wheelResetTimer = setTimeout(() => { this.wheelAccum = 0; }, 140);

    const THRESHOLD = 45;
    if (this.wheelAccum > THRESHOLD) {
      this.wheelAccum = 0;
      this.goTo(this.activeIndex + 1);
    } else if (this.wheelAccum < -THRESHOLD) {
      this.wheelAccum = 0;
      this.goTo(this.activeIndex - 1);
    }
  }

  @HostListener('window:keydown', ['$event'])
  onKeydown(e: KeyboardEvent) {
    if (this.isAnimating) return;
    if (e.key === 'ArrowDown' || e.key === 'PageDown') {
      e.preventDefault();
      this.goTo(this.activeIndex + 1);
    } else if (e.key === 'ArrowUp' || e.key === 'PageUp') {
      e.preventDefault();
      this.goTo(this.activeIndex - 1);
    }
  }

  @HostListener('window:touchstart', ['$event'])
  onTouchStart(e: TouchEvent) {
    this.touchStartY = e.touches[0].clientY;
  }

  @HostListener('window:touchend', ['$event'])
  onTouchEnd(e: TouchEvent) {
    if (this.isAnimating) return;
    const dy = this.touchStartY - e.changedTouches[0].clientY;
    const SWIPE_THRESHOLD = 60;
    if (dy > SWIPE_THRESHOLD) this.goTo(this.activeIndex + 1);
    else if (dy < -SWIPE_THRESHOLD) this.goTo(this.activeIndex - 1);
  }
}
