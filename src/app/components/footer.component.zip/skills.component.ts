import {
  Component,
  ElementRef,
  ViewChild,
  AfterViewInit,
  OnDestroy,
  HostListener,
} from "@angular/core";
import { CommonModule } from "@angular/common";
import { RevealDirective } from "../../directives/reveal.directive";

interface TreeLight {
  anchorX: number;
  anchorY: number;
  angle: number;
  angVel: number;
  len: number;
  skill: string;
  color: string;
  twinklePhase: number;
  glow: number;
}

interface SkillTree {
  name: string;
  accent: string;
  skills: { name: string; color: string }[];
  skillsStr: string;
  x: number;
  y: number;
  w: number;
  h: number;
  lights: TreeLight[];
}

interface Sparkle {
  x: number; y: number; vx: number; vy: number;
  r: number; alpha: number; color: string;
}

interface Leaf {
  x: number; y: number; size: number; rot: number; speed: number; sway: number;
}

@Component({
  selector: "app-skills",
  standalone: true,
  imports: [CommonModule, RevealDirective],
  template: `
    <section id="skills" class="section">
      <div class="container">
        <div class="sk-header" appReveal>
          <h2 class="sk-title serif">Technical Skills</h2>
        </div>

        <div class="tree-stage">
          <canvas
            #treeCanvas
            (mousemove)="onMove($event)"
            (mouseleave)="hovered = null"
            (click)="onClick($event)"
          ></canvas>
          <div
            class="tooltip"
            [style.opacity]="hovered ? 1 : 0"
            [style.left]="tooltipX + 'px'"
            [style.top]="tooltipY + 'px'"
          >
            {{ hovered }}
          </div>
        </div>

        <div class="legend" appReveal>
          <div
            *ngFor="let t of treeData"
            class="legend-item"
            [style.--accent]="t.accent"
          >
            <span class="legend-dot"></span>
            <span class="legend-name">{{ t.name }}</span>
            <span class="legend-skills">{{ t.skillsStr }}</span>
          </div>
        </div>
      </div>
    </section>
  `,
  styles: [
    `
      .serif {
        font-family: "DM Serif Display", serif;
      }
      .sk-header {
        margin-bottom: 40px;
      }
      .sk-title {
        font-size: clamp(2rem, 4vw, 3rem);
        color: #111;
      }

      .tree-stage {
        position: relative;
        width: 100%;
        height: 560px;
        border-radius: 28px;
        overflow: hidden;
        background: rgba(0, 0, 0, 0.02);
        border: 1px solid rgba(0, 0, 0, 0.05);
        canvas {
          display: block;
          width: 100%;
          height: 100%;
          cursor: pointer;
        }
      }

      .tooltip {
        position: absolute;
        pointer-events: none;
        padding: 6px 14px;
        border-radius: 100px;
        background: #111;
        color: #fff;
        font-size: 12px;
        font-weight: 500;
        white-space: nowrap;
        transform: translate(-50%, -100%) translateY(-12px);
        transition: opacity 0.15s;
      }

      .legend {
        display: flex;
        flex-wrap: wrap;
        gap: 12px 32px;
        margin-top: 28px;
      }
      .legend-item {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .legend-dot {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: var(--accent);
        flex-shrink: 0;
      }
      .legend-name {
        font-size: 13px;
        font-weight: 600;
        color: #111;
        white-space: nowrap;
      }
      .legend-skills {
        font-size: 12px;
        color: #999;
      }

      @media (max-width: 640px) {
        .tree-stage {
          height: 480px;
        }
        .legend {
          flex-direction: column;
          gap: 8px;
        }
      }
    `,
  ],
})
export class SkillsComponent implements AfterViewInit, OnDestroy {
  @ViewChild("treeCanvas", { static: false })
  canvasRef!: ElementRef<HTMLCanvasElement>;

  treeData: SkillTree[] = [];
  hovered: string | null = null;
  tooltipX = 0;
  tooltipY = 0;

  private ctx!: CanvasRenderingContext2D;
  private W = 0;
  private H = 0;
  private dpr = 1;
  private animId = 0;
  private time = 0;
  private wind = 0;
  private sparkles: Sparkle[] = [];
  private leaves: Leaf[] = [];
  private windParticles: {
    x: number;
    y: number;
    life: number;
    speed: number;
  }[] = [];

  private raw = [
    {
      name: "Languages",
      accent: "#4facfe",
      skills: [
        { name: "JavaScript (ES6+)", color: "#f7df1e" },
        { name: "TypeScript", color: "#3178c6" },
        { name: "C#", color: "#68217a" },
        { name: "Java", color: "#ed8b00" },
        { name: "HTML5", color: "#e34f26" },
        { name: "CSS3", color: "#1572b6" },
        { name: "SCSS", color: "#c6538c" },
      ],
    },
    {
      name: "Backend & APIs",
      accent: "#43e97b",
      skills: [
        { name: "Node.js", color: "#339933" },
        { name: "Express.js", color: "#555" },
        { name: "REST APIs", color: "#ff6c37" },
        { name: "Webhook Integration", color: "#8854d0" },
        { name: ".NET Webforms", color: "#512bd4" },
        { name: "ASP.NET", color: "#8c4d9e" },
        { name: "SQL Server", color: "#e38c00" },
      ],
    },
    {
      name: "Frontend",
      accent: "#f5576c",
      skills: [
        { name: "Angular (v12–v19)", color: "#dd0031" },
        { name: "RxJS", color: "#e81a6d" },
        { name: "NgRx", color: "#ba2bd2" },
        { name: "Angular Material", color: "#1e88e5" },
        { name: "Highcharts", color: "#2b2b6e" },
        { name: "Bootstrap", color: "#7952b3" },
        { name: "React", color: "#61dafb" },
      ],
    },
    {
      name: "Integrations",
      accent: "#fcb69f",
      skills: [
        { name: "BBPS", color: "#20bf6b" },
        { name: "Payment Gateways", color: "#eb3b5a" },
        { name: "Slack API", color: "#4a154b" },
        { name: "AI Bots", color: "#45aaf2" },
        { name: "WebSockets", color: "#f7b731" },
      ],
    },
    {
      name: "Architecture",
      accent: "#a18cd1",
      skills: [
        { name: "Microservices", color: "#0abde3" },
        { name: "Lazy Loading", color: "#78e08f" },
        { name: "Code Splitting", color: "#e77f67" },
        { name: "Component-Driven", color: "#3dc1d3" },
        { name: "MVVM", color: "#b71540" },
        { name: "Module Federation", color: "#2496ed" },
      ],
    },
    {
      name: "Tools & DevOps",
      accent: "#ffd93d",
      skills: [
        { name: "Git", color: "#f05032" },
        { name: "GitHub", color: "#333" },
        { name: "Postman", color: "#ff6c37" },
        { name: "JIRA", color: "#0052cc" },
        { name: "Webpack", color: "#8dd6f9" },
        { name: "Jasmine", color: "#8a4182" },
        { name: "Karma", color: "#3cb371" },
        { name: "Chrome DevTools", color: "#4285f4" },
        { name: "Angular CLI", color: "#dd0031" },
        { name: "CI/CD", color: "#0abde3" },
      ],
    },
  ];

  ngAfterViewInit(): void {
    this.initCanvas();
    this.initWindParticles();
    this.initLeaves();
    this.initTrees();
    this.loop();
  }

  ngOnDestroy(): void {
    cancelAnimationFrame(this.animId);
  }

  @HostListener("window:resize")
  onResize(): void {
    this.initCanvas();
    this.initTrees();
  }

  private initCanvas(): void {
    const cvs = this.canvasRef.nativeElement;
    this.dpr = window.devicePixelRatio || 1;
    const rect = cvs.parentElement!.getBoundingClientRect();
    this.W = rect.width;
    this.H = rect.height;
    cvs.width = this.W * this.dpr;
    cvs.height = this.H * this.dpr;
    cvs.style.width = this.W + "px";
    cvs.style.height = this.H + "px";
    this.ctx = cvs.getContext("2d")!;
    this.ctx.scale(this.dpr, this.dpr);
  }

  // private initTrees(): void {
  //   this.treeData = [];
  //   const count = this.raw.length;
  //   const cols = count;
  //   const gap = 12;
  //   const colGap = gap;
  //   const totalColGap = colGap * (cols - 1);
  //   const treeW = Math.min((this.W - totalColGap) / cols, 190);
  //   const treeH = this.H * 0.82;
  //   const treeTop = this.H * 0.06;

  //   const totalW = cols * treeW + totalColGap;
  //   const offsetX = Math.max(0, (this.W - totalW) / 2);

  //   for (let i = 0; i < count; i++) {
  //     const r = this.raw[i];
  //     const x = offsetX + colGap / 2 + i * (treeW + colGap) + treeW / 2;
  //     const y = treeTop;
  //     const lights: TreeLight[] = [];
  //     const layers = 4;
  //     const layerH = treeH / (layers + 0.5);
  //     const half = r.skills.length / 2;

  //     r.skills.forEach((sk, idx) => {
  //       const layerIdx = Math.floor(idx / Math.ceil(half / layers));
  //       const clampedLayer = Math.min(layerIdx, layers - 1);
  //       const t = 0.15 + (idx / r.skills.length) * 0.7;
  //       const side = idx % 2 === 0 ? 1 : -1;

  //       const layerY = y + clampedLayer * layerH;
  //       const layerW = treeW * (0.3 + ((layers - 1 - clampedLayer) / layers) * 0.7);
  //       const anchorX = side * layerW * t * 0.4;
  //       const anchorY = layerY - y + layerH * 0.25 + Math.random() * layerH * 0.15;

  //       const stringLen = 14 + Math.random() * 14;

  //       lights.push({
  //         anchorX, anchorY,
  //         angle: (Math.random() - 0.5) * 0.15,
  //         angVel: 0,
  //         len: stringLen,
  //         skill: sk.name,
  //         color: sk.color,
  //         twinklePhase: Math.random() * Math.PI * 2,
  //         glow: 0,
  //       });
  //     });

  //     this.treeData.push({
  //       name: r.name,
  //       accent: r.accent,
  //       skills: r.skills,
  //       skillsStr: r.skills.map(s => s.name).join(' | '),
  //       x, y, w: treeW, h: treeH,
  //       lights,
  //     });
  //   }

  //   this.windParticles = [];
  //   for (let i = 0; i < 10; i++) {
  //     this.windParticles.push({
  //       x: Math.random() * this.W,
  //       y: Math.random() * this.H,
  //       life: Math.random(),
  //       speed: 0.3 + Math.random() * 0.6,
  //     });
  //   }
  // }
  private initTrees(): void {
    this.treeData = [];

    const count = this.raw.length;

    // responsive spacing
    const sidePadding = 20;
    const gap = Math.max(8, this.W * 0.008);

    // fit ALL trees inside one row
    const availableW = this.W - sidePadding * 2 - gap * (count - 1);

    // remove hard 190 cap
    const treeW = Math.max(
      85,
      Math.min(availableW / count, this.W / (count + 0.3)),
    );

    const treeH = Math.min(this.H * 0.82, treeW * 2.2);
    const treeTop = this.H * 0.06;

    const totalW = count * treeW + gap * (count - 1);
    const startX = (this.W - totalW) / 2;

    for (let i = 0; i < count; i++) {
      const r = this.raw[i];

      const x = startX + i * (treeW + gap) + treeW / 2;

      const lights: TreeLight[] = [];

      const layers = 4;
      const layerH = treeH / (layers + 0.5);
      const perLayer = Math.ceil(r.skills.length / layers);

      r.skills.forEach((sk, idx) => {
        const layer = Math.min(Math.floor(idx / perLayer), layers - 1);

        // top → bottom positioning
        const layerY = treeTop + layer * layerH;

        // narrow top → wide bottom
        const layerWidth = treeW * (0.35 + (layer / (layers - 1)) * 0.65);

        const side = idx % 2 ? -1 : 1;
        const spread = ((idx % perLayer) + 1) / (perLayer + 1);

        lights.push({
          anchorX: side * layerWidth * spread * 0.32,

          anchorY: layerY - treeTop + layerH * 0.45,

          angle: (Math.random() - 0.5) * 0.15,
          angVel: 0,
          len: 38 + Math.random() * 34,

          skill: sk.name,
          color: sk.color,
          twinklePhase: Math.random() * Math.PI * 2,
          glow: 0,
        });
      });

      this.treeData.push({
        name: r.name,
        accent: r.accent,
        skills: r.skills,
        skillsStr: r.skills.map((s) => s.name).join(" | "),
        x,
        y: treeTop,
        w: treeW,
        h: treeH,
        lights,
      });
    }
    console.log("Trees created:", this.treeData.length);
  }

  private initWindParticles(): void {
    this.windParticles = [];
    for (let i = 0; i < 20; i++) {
      this.windParticles.push({
        x: Math.random() * this.W,
        y: Math.random() * this.H,
        life: Math.random(),
        speed: 0.3 + Math.random() * 0.8,
      });
    }
  }

  private initLeaves(): void {
    this.leaves = [];
    for (let i = 0; i < 32; i++) {
      this.leaves.push({
        x: Math.random() * this.W,
        y: Math.random() * this.H,
        size: 4 + Math.random() * 10,
        rot: Math.random() * 6,
        speed: 0.4 + Math.random() * 1.2,
        sway: Math.random() * 3,
      });
    }
  }

  onMove(e: MouseEvent): void {
    const rect = (e.target as HTMLCanvasElement).getBoundingClientRect();
    const cx = e.clientX - rect.left;
    const cy = e.clientY - rect.top;

    for (const tree of this.treeData) {
      for (const lt of tree.lights) {
        if (!lt.skill) continue;
        const { lx, ly } = this.lightPos(tree, lt);
        const d = Math.hypot(cx - lx, cy - ly);
        if (d < 20) {
          this.hovered = lt.skill;
          this.tooltipX = e.clientX - rect.left;
          this.tooltipY = e.clientY - rect.top;
          lt.glow = 1;
          return;
        }
      }
    }
    this.hovered = null;
  }

  onClick(e: MouseEvent): void {
    const rect = (e.target as HTMLCanvasElement).getBoundingClientRect();
    const cx = e.clientX - rect.left;
    const cy = e.clientY - rect.top;

    for (const tree of this.treeData) {
      for (const lt of tree.lights) {
        const { lx, ly } = this.lightPos(tree, lt);
        const d = Math.hypot(cx - lx, cy - ly);
        if (d < 22) {
          for (let i = 0; i < 14; i++) {
            const a = Math.random() * Math.PI * 2;
            const s = 1 + Math.random() * 3;
            this.sparkles.push({
              x: lx,
              y: ly,
              vx: Math.cos(a) * s,
              vy: Math.sin(a) * s,
              r: 2 + Math.random() * 3,
              alpha: 1,
              color: lt.color,
            });
          }
          return;
        }
      }
    }
  }

  private lightPos(tree: SkillTree, lt: TreeLight): { lx: number; ly: number } {
    const lx = tree.x + lt.anchorX + Math.sin(lt.angle) * lt.len;
    const ly = tree.y + lt.anchorY + Math.cos(lt.angle) * lt.len;
    return { lx, ly };
  }

  private loop = (): void => {
    this.time += 0.016;
    this.wind =
      Math.sin(this.time * 0.5) * 0.5 +
      Math.sin(this.time * 1.0) * 0.3 +
      Math.sin(this.time * 2.1) * 0.2;
    this.update();
    this.draw();
    this.animId = requestAnimationFrame(this.loop);
  };

  private update(): void {
    const damping = 0.975;
    const gravity = 0.008;
    const windStrength = 0.0045;

    for (const tree of this.treeData) {
      for (const lt of tree.lights) {
        const f =
          -gravity * Math.sin(lt.angle) +
          this.wind * windStrength * Math.cos(lt.angle);
        lt.angVel += f;
        lt.angVel *= damping;
        lt.angle += lt.angVel;
        lt.glow *= 0.92;
      }
    }

    for (let i = this.sparkles.length - 1; i >= 0; i--) {
      const s = this.sparkles[i];
      s.x += s.vx;
      s.y += s.vy;
      s.vx *= 0.96;
      s.vy *= 0.96;
      s.alpha -= 0.025;
      s.r *= 0.97;
      if (s.alpha <= 0) this.sparkles.splice(i, 1);
    }

    for (const p of this.windParticles) {
      p.x += this.wind * p.speed * 2 + 0.3;
      p.y += Math.sin(this.time + p.x * 0.01) * 0.2;
      p.life += 0.005;
      if (p.life > 1) { p.life = 0; p.x = -20; p.y = Math.random() * this.H; }
      if (p.x > this.W + 30) { p.x = -20; p.y = Math.random() * this.H; }
    }

    for (const l of this.leaves) {
      l.x += 0.8 + l.speed;
      l.y += Math.sin(this.time + l.sway) * 0.6;
      l.rot += 0.02;
      if (l.x > this.W + 20) { l.x = -20; l.y = Math.random() * this.H; }
    }
  }

  private draw(): void {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.W, this.H);

    // sky gradient
    const skyGrad = ctx.createLinearGradient(0, 0, 0, this.H);
    skyGrad.addColorStop(0, "#c8e6f5");
    skyGrad.addColorStop(0.5, "#e8f0e8");
    skyGrad.addColorStop(1, "#d4d8c8");
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, this.W, this.H);

    // sun
    this.drawSun(ctx);

    // wind streaks
    ctx.strokeStyle = "rgba(255,255,255,0.35)";
    ctx.lineWidth = 2;
    for (const p of this.windParticles) {
      ctx.globalAlpha = 0.35 * (1 - p.life);
      const len = 60 + this.wind * 35;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      const waveY = Math.sin(this.time * 0.8 + p.x * 0.015) * 6 + this.wind * 3;
      ctx.lineTo(p.x - len, p.y + waveY);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    // ground
    ctx.fillStyle = "#b8c0a8";
    ctx.fillRect(0, this.H - 4, this.W, 4);

    // floating leaves
    this.drawLeaves(ctx);

    // trees
    for (const tree of this.treeData) {
      this.drawTree(ctx, tree);
    }

    // sparkles
    for (const s of this.sparkles) {
      ctx.globalAlpha = Math.max(0, s.alpha);
      ctx.fillStyle = s.color;
      ctx.beginPath();
      ctx.arc(s.x, s.y, Math.max(0.5, s.r), 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  private drawSun(ctx: CanvasRenderingContext2D): void {
    const sx = this.W - 70;
    const sy = 42;
    const r = 28;

    // rays
    for (let i = 0; i < 12; i++) {
      const a = (Math.PI / 6) * i + this.time * 0.08;
      const len = 36 + Math.sin(this.time * 1.2 + i) * 6;
      ctx.strokeStyle = `rgba(255,200,50,${0.15 + 0.12 * Math.sin(this.time + i)})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(sx + Math.cos(a) * r, sy + Math.sin(a) * r);
      ctx.lineTo(sx + Math.cos(a) * len, sy + Math.sin(a) * len);
      ctx.stroke();
    }

    const sg = ctx.createRadialGradient(sx - 6, sy - 6, 0, sx, sy, r);
    sg.addColorStop(0, "#fffbe6");
    sg.addColorStop(0.5, "#ffd700");
    sg.addColorStop(1, "#ff8c00");
    ctx.fillStyle = sg;
    ctx.beginPath();
    ctx.arc(sx, sy, r, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "rgba(255,215,0,0.12)";
    ctx.beginPath();
    ctx.arc(sx, sy, r * 2.2, 0, Math.PI * 2);
    ctx.fill();
  }

  private drawTree(ctx: CanvasRenderingContext2D, tree: SkillTree): void {
    const { x, y, w, h, lights } = tree;
    const layers = 4;
    const layerH = h / (layers + 0.5);

    // trunk
    ctx.fillStyle = "#5d4037";
    ctx.beginPath();
    ctx.rect(x - 7, y + h - layerH * 0.3, 14, layerH * 0.3);
    ctx.fill();

    // tree layers (bottom to top, widest at bottom)
    for (let i = 0; i < layers; i++) {
      const ly = y + i * layerH;
      const lw = w * (0.3 + ((layers - 1 - i) / layers) * 0.7);
      const overlap = layerH * 0.12;

      const grad = ctx.createLinearGradient(
        x - lw / 2,
        ly,
        x + lw / 2,
        ly + layerH + overlap,
      );
      const dark = 18 + (layers - 1 - i) * 10;
      grad.addColorStop(
        0,
        `rgb(${dark + 10}, ${45 + (layers - 1 - i) * 6}, ${18 + (layers - 1 - i) * 3})`,
      );
      grad.addColorStop(
        0.5,
        `rgb(${dark + 20}, ${55 + (layers - 1 - i) * 6}, ${22 + (layers - 1 - i) * 3})`,
      );
      grad.addColorStop(
        1,
        `rgb(${dark + 10}, ${45 + (layers - 1 - i) * 6}, ${18 + (layers - 1 - i) * 3})`,
      );
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(x, ly);
      ctx.lineTo(x + lw / 2, ly + layerH + overlap);
      ctx.lineTo(x - lw / 2, ly + layerH + overlap);
      ctx.closePath();
      ctx.fill();

      ctx.strokeStyle = "rgba(255,255,255,0.05)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x, ly);
      ctx.lineTo(x + lw / 2, ly + layerH + overlap);
      ctx.stroke();

      // leaves along the edges
      const leafCount = 4 + i * 2;
      for (let lf = 0; lf < leafCount; lf++) {
        const lt = (lf + 0.5) / leafCount;
        const lx = x - lw / 2 + lt * lw;
        const ly2 = ly + lt * (layerH + overlap);
        const leafSize = 2.5 + (layers - 1 - i) * 1.2;
        ctx.fillStyle = `rgba(50, ${80 + i * 10}, ${30 + i * 5}, 0.4)`;
        ctx.beginPath();
        ctx.ellipse(lx, ly2, leafSize, leafSize * 0.6, lt * 0.8 - 0.4, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // star
    this.drawTreeStar(ctx, x, y - 4);

    // strings and lights
    for (const lt of lights) {
      const { lx, ly } = this.lightPos(tree, lt);
      const twinkle = 0.5 + 0.5 * Math.sin(this.time * 2.5 + lt.twinklePhase);
      const glowInt = Math.max(twinkle, lt.glow);

      // string with wind curve
      ctx.strokeStyle = "rgba(255,255,255,0.25)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(tree.x + lt.anchorX, tree.y + lt.anchorY);
      const midX = (tree.x + lt.anchorX + lx) / 2 + this.wind * 4;
      const midY = (tree.y + lt.anchorY + ly) / 2;
      ctx.quadraticCurveTo(midX, midY, lx, ly);
      ctx.stroke();

      // glow
      const gRad = 7 + glowInt * 8;
      const gg = ctx.createRadialGradient(lx, ly, 0, lx, ly, gRad);
      // const alphaHex = Math.round(50 * glowInt).toString(16).padStart(2, '0');
      // gg.addColorStop(0, lt.color + alphaHex);
      // gg.addColorStop(1, lt.color + '00');
      // ctx.fillStyle = gg;
      // ctx.beginPath();
      // ctx.arc(lx, ly, gRad, 0, Math.PI * 2);
      // ctx.fill();
      const alpha = Math.max(0, Math.min(255, Math.round(50 * glowInt)));

      const alphaHex = alpha.toString(16).padStart(2, "0");

      // make sure color is valid
      const base =
        lt.color.length === 4
          ? "#" +
            lt.color[1] +
            lt.color[1] +
            lt.color[2] +
            lt.color[2] +
            lt.color[3] +
            lt.color[3]
          : lt.color;

      gg.addColorStop(0, `${base}${alphaHex}`);

      gg.addColorStop(1, `${base}00`);

      ctx.fillStyle = gg;

      ctx.beginPath();

      ctx.arc(lx, ly, gRad, 0, Math.PI * 2);

      ctx.fill();
      // light core (bigger)
      const cRad = 7.5 + twinkle * 2 + lt.glow * 5;
      ctx.fillStyle = lt.color;
      ctx.beginPath();
      ctx.arc(lx, ly, cRad, 0, Math.PI * 2);
      ctx.fill();

      // white center
      ctx.fillStyle = `rgba(255,255,255,${0.3 + 0.5 * twinkle})`;
      ctx.beginPath();
      ctx.arc(lx, ly, cRad * 0.35, 0, Math.PI * 2);
      ctx.fill();

      // glass bulb ring
      ctx.strokeStyle = 'rgba(255,255,255,.5)';
      ctx.lineWidth = .6;
      ctx.beginPath();
      ctx.arc(lx, ly, cRad + 1.5, 0, Math.PI * 2);
      ctx.stroke();
    }

    // tree name below trunk
    const nameY = y + h + 6;
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    ctx.font = "600 13px DM Serif Display";
    ctx.fillStyle = tree.accent;
    ctx.shadowColor = tree.accent;
    ctx.shadowBlur = 12;
    ctx.fillText(tree.name, x, nameY);
    ctx.shadowBlur = 0;
  }

  private drawLeaves(ctx: CanvasRenderingContext2D): void {
    for (const l of this.leaves) {
      ctx.save();
      ctx.translate(l.x, l.y);
      ctx.rotate(l.rot);
      ctx.fillStyle = 'rgba(80,120,60,.32)';
      ctx.beginPath();
      ctx.ellipse(0, 0, l.size, l.size * .45, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  private drawTreeStar(
    ctx: CanvasRenderingContext2D,
    cx: number,
    cy: number,
  ): void {
    const starR = 9 + Math.sin(this.time * 2) * 1.2;
    const sg = ctx.createRadialGradient(cx, cy, 0, cx, cy, starR);
    sg.addColorStop(0, "#fffbe6");
    sg.addColorStop(0.5, "#ffd700");
    sg.addColorStop(1, "#ff8c00");
    ctx.fillStyle = sg;
    this.drawStarPath(ctx, cx, cy, 5, starR, starR * 0.45);
    ctx.fill();

    ctx.fillStyle = "rgba(255,215,0,0.12)";
    ctx.beginPath();
    ctx.arc(cx, cy, starR * 2.2, 0, Math.PI * 2);
    ctx.fill();
  }

  private drawStarPath(
    ctx: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    points: number,
    outer: number,
    inner: number,
  ): void {
    ctx.beginPath();
    for (let i = 0; i < points * 2; i++) {
      const r = i % 2 === 0 ? outer : inner;
      const a = (Math.PI / points) * i - Math.PI / 2;
      const x = cx + Math.cos(a) * r;
      const y = cy + Math.sin(a) * r;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
  }
}
