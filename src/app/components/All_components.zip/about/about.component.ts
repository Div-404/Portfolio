import { Component, ElementRef, HostListener, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RevealDirective } from '../../directives/reveal.directive';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule, RevealDirective],
  template: `
    <section #aboutSection id="about" class="section">
      <div class="container">
        <div class="about-grid">

          <div class="about-left">
            <span class="eyebrow" appReveal>Hey!</span>
            <div #textContent class="about-text-wrap">
              <p class="about-intro" appReveal>
                <span class="word" *ngFor="let w of introWords; let i = index"
                      [class.revealed]="i < revealedCount">{{ w }} </span>
              </p>
              <p class="about-body" appReveal [revealDelay]="80">
                <span class="word" *ngFor="let w of bodyWords1; let i = index"
                      [class.revealed]="introWords.length + i < revealedCount">{{ w }} </span>
              </p>
              <p class="about-body" appReveal [revealDelay]="140">
                <span class="word" *ngFor="let w of bodyWords2; let i = index"
                      [class.revealed]="introWords.length + bodyWords1.length + i < revealedCount">{{ w }} </span>
              </p>
            </div>
            <a href="assets/resume/Shivam_Kumar_Divaker.pdf" download class="about-cta" appReveal [revealDelay]="200">
              Download Resume ↓
            </a>
          </div>

          <div class="about-right">
            <div class="photo-switcher" #switcher>
              <img
                *ngFor="let img of photos; let i = index"
                [src]="img"
                alt="Shivam"
                class="about-img"
                [class.active]="i === activePhoto"
                onerror="this.style.display='none'">
              <div class="photo-dots">
                <span *ngFor="let img of photos; let i = index" [class.active]="i === activePhoto"></span>
              </div>
            </div>

            <div class="about-stats">
              <div class="stat" *ngFor="let s of stats; let i = index" appReveal [revealDelay]="i * 80">
                <div class="stat-val">{{ s.value }}</div>
                <div class="stat-lbl">{{ s.label }}</div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  `,
  styles: [`
    .about-grid {
      display: grid; grid-template-columns: 1fr 1fr;
      gap: 80px; align-items: start; margin-bottom: 64px;
    }
    .about-intro {
      font-family: 'DM Serif Display', serif;
      font-size: clamp(1.4rem, 2.5vw, 1.9rem);
      line-height: 1.3; color: #111; margin-bottom: 24px;
    }
    .about-body { font-size: 15px; color: #666; line-height: 1.8; margin-bottom: 16px; }

    .about-intro .word {
      color: #d4d0c8;
      transition: color 0.3s ease;
    }
    .about-intro .word.revealed {
      color: #111;
    }
    .about-body .word {
      color: #d4d0c8;
      transition: color 0.3s ease;
    }
    .about-body .word.revealed {
      color: #666;
    }

    .about-cta {
      display: inline-flex; align-items: center; gap: 8px;
      margin-top: 24px; padding: 12px 28px;
      border: 1.5px solid #111; border-radius: 100px;
      font-size: 13px; font-weight: 500; color: #111;
      transition: background 0.2s, color 0.2s;
      &:hover { background: #111; color: #f0ece3; }
    }

    .photo-switcher {
      position: relative;
      width: 100%; aspect-ratio: 3/4;
      border-radius: 12px; margin-bottom: 24px; overflow: hidden;
      border: 1px solid rgba(0,0,0,0.08);
      background: #e8e4db;
    }
    .about-img {
      position: absolute; inset: 0;
      width: 100%; height: 100%; object-fit: cover; object-position: top;
      opacity: 0; transform: scale(1.04);
      transition: opacity 0.8s ease, transform 1.2s ease;
    }
    .about-img.active { opacity: 1; transform: scale(1); }
    .photo-dots {
      position: absolute; bottom: 14px; left: 50%; transform: translateX(-50%);
      display: flex; gap: 6px; z-index: 2;
    }
    .photo-dots span {
      width: 6px; height: 6px; border-radius: 50%;
      background: rgba(255,255,255,0.4);
      transition: background 0.3s, transform 0.3s;
    }
    .photo-dots span.active { background: #f0ece3; transform: scale(1.3); }

    .about-stats { display: flex; gap: 32px; flex-wrap: wrap; }
    .stat-val { font-family: 'DM Serif Display', serif; font-size: 2.4rem; color: #111; line-height: 1; }
    .stat-lbl { font-size: 12px; color: #999; margin-top: 4px; font-family: 'Space Mono', monospace; letter-spacing: 0.05em; }


    @media (max-width: 768px) {
      .about-grid { grid-template-columns: 1fr; gap: 40px; }
      .photo-switcher { aspect-ratio: 4/3; }
    }
  `]
})
export class AboutComponent implements OnInit {
  @ViewChild('switcher') switcherEl!: ElementRef<HTMLElement>;
  @ViewChild('textContent', { static: true }) textContent!: ElementRef;

  photos = [
    'assets/images/avatar-bust.jpg',
    'assets/images/avatar-suit.png',
    'assets/images/Gemini_Generated_Image_ubokpzubokpzubok.png'
  ];
  activePhoto = 0;

  stats = [
    { value: '4+', label: 'Years Building' },
    { value: '15+', label: 'Projects Shipped' },
    { value: '8+', label: 'Technologies' }
  ];


  introWords: string[] = [];
  bodyWords1: string[] = [];
  bodyWords2: string[] = [];
  totalWords = 0;
  revealedCount = 0;

  private introText = "I'm Shivam, a builder based in Delhi, India, currently working on scalable Angular applications and Node.js backends.";
  private bodyText1 = "I'm a software engineer with a strong focus on building modern, performant, and maintainable web experiences. I specialise in Angular, reactive programming with RxJS, and real-time interfaces using WebSockets.";
  private bodyText2 = "Over the past few years I've built trading platforms, permission-driven dashboards, and component libraries used in production — always staying close to the problem and shipping things that hold up.";

  ngOnInit() {
    this.introWords = this.introText.split(/\s+/);
    this.bodyWords1 = this.bodyText1.split(/\s+/);
    this.bodyWords2 = this.bodyText2.split(/\s+/);
    this.totalWords = this.introWords.length + this.bodyWords1.length + this.bodyWords2.length;
    this.updateReveal();
  }

  @HostListener('window:scroll')
  onScroll() {
    this.updateReveal();

    if (!this.switcherEl) return;
    const rect = this.switcherEl.nativeElement.getBoundingClientRect();
    const vh = window.innerHeight;

    const total = rect.height + vh;
    const traveled = vh - rect.top;
    const progress = Math.min(1, Math.max(0, traveled / total));

    const idx = Math.min(
      this.photos.length - 1,
      Math.floor(progress * this.photos.length)
    );
    if (idx !== this.activePhoto) this.activePhoto = idx;
  }

  private updateReveal() {
    const el = this.textContent?.nativeElement;
    if (!el) return;

    const rect = el.getBoundingClientRect();
    const vh = window.innerHeight;

    const top = rect.top + window.scrollY;
    const h = rect.height;

    const startReveal = top - vh;
    const endReveal = top + h - vh * 0.15;

    const progress = endReveal > startReveal
      ? Math.max(0, Math.min(1, (window.scrollY - startReveal) / (endReveal - startReveal)))
      : 1;

    this.revealedCount = Math.floor(progress * this.totalWords);
  }
}
