import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RevealDirective } from '../../directives/reveal.directive';

@Component({
  selector: 'app-hero',
  standalone: true,
  imports: [CommonModule, RevealDirective],
  template: `
    <section id="hero" class="hero">
      <div class="container hero-content">
        <div class="hero-top">
          <div class="hero-badge">
            <span class="dot"></span>
            <span>Shivam Kumar Divaker</span>
          </div>
          <span class="hero-year">©{{ year }}</span>
        </div>

        <div class="hero-main">
          <div class="hero-left">
            <h1 class="hero-title">
              <span class="line" appReveal>SOFTWARE</span>
              <span class="line" appReveal [revealDelay]="120">ENGINEER</span>
            </h1>
          </div>
          <div class="hero-mid"></div>
          <div class="hero-right">
            <p class="hero-desc" appReveal [revealDelay]="220">
              I'm Shivam, a builder based in Delhi, India.<br>
              Currently crafting Angular apps and scalable<br>
              Node.js backends.
            </p>
            <div class="hero-actions" appReveal [revealDelay]="320">
              <a href="#projects" class="btn-primary">View Work →</a>
              <a href="#contact" class="btn-ghost">Get in Touch</a>
            </div>
          </div>
        </div>
      </div>

      <div class="marquee-strip">
        <div class="marquee-track">
          <ng-container *ngFor="let _ of [1,2,3]">
            <span *ngFor="let t of tech" class="m-item">
              {{ t }}&nbsp;&nbsp;<span class="m-sep">✦</span>&nbsp;&nbsp;
            </span>
          </ng-container>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .hero {
      position: relative;
      min-height: 100vh; padding-top: 60px;
      display: flex; flex-direction: column; justify-content: center;
      border-bottom: 1px solid rgba(0,0,0,0.08);
      overflow: hidden;
      background: transparent;
    }
    .hero-content { position: relative; z-index: 1; width: 100%; }

    .hero-top {
      display: flex; align-items: center; justify-content: space-between;
      padding: 32px 0 28px; border-bottom: 1px solid rgba(0,0,0,0.08);
    }
    .hero-badge {
      display: flex; align-items: center; gap: 8px;
      font-size: 12px; color: #666;
    }
    .dot {
      width: 7px; height: 7px; border-radius: 50%; background: #111;
      animation: blink 2s ease infinite;
    }
    @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.3} }
    .hero-year { font-family: 'Space Mono', monospace; font-size: 12px; color: #999; }

    .hero-main {
      display: flex;
      align-items: center;
      gap: 40px;
      padding: 40px 0;
      min-height: 60vh;
    }

    .hero-left {
      flex: 0 0 auto;
      max-width: 400px;
      margin-right: auto;
      margin-left: -60px;
    }

    .hero-title {
      font-family: 'DM Serif Display', serif;
      font-size: clamp(3.2rem, 8vw, 6rem);
      font-weight: 400;
      line-height: 0.92;
      letter-spacing: -0.02em;
      color: #111;
      display: flex;
      flex-direction: column;
      gap: 6px;
      margin: 0;
    }

    .hero-mid {
      flex: 1;
      min-height: 50vh;
    }

    .hero-right {
      flex: 1;
      max-width: 400px;
    }

    .hero-desc {
      font-size: 15px; color: #666; line-height: 1.7;
      margin: 0 0 32px;
    }

    .hero-actions {
      display: flex; gap: 12px;
    }

    .btn-primary {
      padding: 12px 28px; background: #111; color: #f0ece3;
      border-radius: 100px; font-size: 13px; font-weight: 500;
      transition: opacity 0.2s;
      &:hover { opacity: 0.8; }
    }
    .btn-ghost {
      padding: 12px 28px; border: 1.5px solid rgba(0,0,0,0.2);
      border-radius: 100px; font-size: 13px; color: #444;
      transition: border-color 0.2s, color 0.2s;
      &:hover { border-color: #111; color: #111; }
    }

    .marquee-strip {
      position: relative; z-index: 1;
      overflow: hidden; border-top: 1px solid rgba(0,0,0,0.08);
      padding: 16px 0; margin-top: auto;
      background: #f0ece3;
    }
    .marquee-track {
      display: flex; width: max-content;
      animation: marquee 28s linear infinite;
    }
    @keyframes marquee { from{transform:translateX(0)} to{transform:translateX(-33.33%)} }
    .m-item { font-family: 'Space Mono', monospace; font-size: 11px; color: #aaa; letter-spacing: 0.08em; white-space: nowrap; }
    .m-sep { color: #111; }

    @media (max-width: 768px) {
      .hero-title { font-size: clamp(2.4rem, 10vw, 4rem); }
      .hero-main { flex-direction: column; padding: 24px 0; }
      .hero-mid { min-height: 30vh; width: 100%; }
    }
  `]
})
export class HeroComponent {
  year = new Date().getFullYear();
  tech = ['Angular', 'TypeScript', 'Node.js', 'RxJS', 'SCSS', 'MongoDB', 'Express', 'WebSockets', 'REST APIs', 'Git'];
}
