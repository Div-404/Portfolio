import { Component, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-nav',
  standalone: true,
  imports: [CommonModule],
  template: `
    <nav [class.scrolled]="scrolled">
      <div class="nav-inner">
        <a href="#hero" class="nav-brand">Shivam</a>
        <div class="nav-right">
          <ul class="nav-links">
            <li><a href="#about">About</a></li>
            <li><a href="#projects">Work</a></li>
            <li><a href="#skills">Skills</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
          <a href="assets/resume/Shivam_Kumar_Divaker.pdf" download class="nav-btn">Resume</a>
          <button class="hamburger" (click)="menuOpen=!menuOpen" [class.open]="menuOpen" aria-label="Menu">
            <span></span><span></span>
          </button>
        </div>
      </div>
      <div class="mobile-menu" [class.open]="menuOpen">
        <a href="#about"    (click)="menuOpen=false">About</a>
        <a href="#projects" (click)="menuOpen=false">Work</a>
        <a href="#skills"   (click)="menuOpen=false">Skills</a>
        <a href="#contact"  (click)="menuOpen=false">Contact</a>
        <a href="assets/resume/Shivam_Kumar_Divaker.pdf" download class="mob-btn" (click)="menuOpen=false">Resume ↓</a>
      </div>
    </nav>
  `,
  styles: [`
    nav {
      position: fixed; top: 0; left: 0; right: 0; z-index: 1000;
      height: 60px; padding: 0 40px;
      display: flex; align-items: center;
      transition: background 0.3s, border-color 0.3s, backdrop-filter 0.3s;
      border-bottom: 1px solid transparent;
    }
    nav.scrolled {
      background: rgba(240,236,227,0.88);
      backdrop-filter: blur(16px);
      border-bottom-color: rgba(0,0,0,0.08);
    }
    .nav-inner { width: 100%; max-width: 1100px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; }
    .nav-brand { font-family: 'DM Serif Display', serif; font-size: 20px; color: #111; letter-spacing: -0.01em; }
    .nav-right { display: flex; align-items: center; gap: 32px; }
    .nav-links { display: flex; list-style: none; gap: 28px;
      a { font-size: 13px; color: #666; transition: color 0.2s; &:hover { color: #111; } }
    }
    .nav-btn {
      padding: 8px 20px; border: 1.5px solid #111; border-radius: 100px;
      font-size: 12px; font-weight: 500; color: #111;
      transition: background 0.2s, color 0.2s;
      &:hover { background: #111; color: #f0ece3; }
    }
    .hamburger {
      display: none; flex-direction: column; gap: 5px;
      background: none; border: none; cursor: pointer; padding: 4px;
      span { display: block; width: 20px; height: 1.5px; background: #111; transition: transform 0.3s; }
      &.open span:first-child { transform: translateY(6.5px) rotate(45deg); }
      &.open span:last-child  { transform: translateY(-6.5px) rotate(-45deg); }
    }
    .mobile-menu {
      display: none; position: fixed; top: 60px; left: 0; right: 0;
      background: #f0ece3; border-bottom: 1px solid rgba(0,0,0,0.08);
      flex-direction: column; padding: 24px 40px; gap: 18px;
      a { font-size: 16px; color: #444; &:hover { color: #111; } }
      .mob-btn { color: #111; font-weight: 600; font-size: 13px; }
    }
    @media (max-width: 768px) {
      nav { padding: 0 20px; }
      .nav-links, .nav-btn { display: none; }
      .hamburger { display: flex; }
      .mobile-menu.open { display: flex; }
    }
  `]
})
export class NavComponent {
  scrolled = false;
  menuOpen = false;
  @HostListener('window:scroll') onScroll() { this.scrolled = window.scrollY > 20; }
}
