import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RevealDirective } from '../../directives/reveal.directive';

@Component({
  selector: 'app-thoughts',
  standalone: true,
  imports: [CommonModule, RevealDirective],
  template: `
    <section id="thoughts" class="section thoughts">
      <div class="container">
        <span class="eyebrow" appReveal>/Notes</span>
        <h2 class="thoughts-title" appReveal>Thoughts</h2>

        <div class="thoughts-grid">
          <a class="t-card t-image" appReveal [revealDelay]="80"
             style="background-image: url('assets/images/avatar-bust.jpg')">
            <div class="t-overlay"></div>
            <div class="t-content">
              <span class="t-date">Settlement Engine</span>
              <h3>Idempotency is the quiet hero of payment systems</h3>
              <p>Retries and webhooks fail in production all the time — designing for
                 "safe to repeat" beats trying to prevent failure entirely.</p>
            </div>
          </a>

          <a class="t-card t-image" appReveal [revealDelay]="160"
             style="background-image: url('assets/images/Gemini_Generated_Image_ubokpzubokpzubok.png')">
            <div class="t-overlay"></div>
            <div class="t-content">
              <span class="t-date">Angular at Scale</span>
              <h3>Reusable components save more time than clever code</h3>
              <p>30+ shared components across 5 product lines taught me that boring,
                 well-documented building blocks beat bespoke solutions every time.</p>
            </div>
          </a>

          <a href="#projects" class="t-card t-cta" appReveal [revealDelay]="240">
            <h3>See how I turn messy backend problems into systems that just run — explore my work</h3>
            <span class="t-link">View All Work <span class="arrow">↗</span></span>
          </a>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .thoughts { background: #f0ece3; }
    .thoughts-title {
      font-family: 'DM Serif Display', serif;
      font-size: clamp(2.4rem, 6vw, 4rem);
      color: #111; margin-bottom: 48px; letter-spacing: -0.02em;
    }

    .thoughts-grid {
      display: grid;
      grid-template-columns: 1fr 1fr 1fr;
      gap: 20px;
    }

    .t-card {
      position: relative;
      border-radius: 14px;
      min-height: 360px;
      display: flex;
      flex-direction: column;
      justify-content: flex-end;
      padding: 28px;
      overflow: hidden;
      transition: transform 0.35s var(--ease);
    }
    .t-card:hover { transform: translateY(-4px); }

    .t-image {
      background-size: cover;
      background-position: center;
      color: #f0ece3;
    }
    .t-overlay {
      position: absolute; inset: 0;
      background: linear-gradient(180deg, rgba(10,10,10,0.05) 0%, rgba(10,10,10,0.85) 85%);
      filter: grayscale(0.4);
    }
    .t-content { position: relative; z-index: 1; }
    .t-date {
      font-family: 'Space Mono', monospace; font-size: 11px;
      letter-spacing: 0.08em; color: rgba(240,236,227,0.7); text-transform: uppercase;
      display: block; margin-bottom: 10px;
    }
    .t-content h3 {
      font-family: 'DM Serif Display', serif;
      font-size: 1.3rem; line-height: 1.25; margin-bottom: 10px; color: #fff;
    }
    .t-content p { font-size: 13px; line-height: 1.6; color: rgba(240,236,227,0.75); }

    .t-cta {
      background: #111;
      color: #f0ece3;
      justify-content: space-between;
    }
    .t-cta h3 {
      font-family: 'DM Serif Display', serif;
      font-size: clamp(1.4rem, 2.4vw, 1.8rem);
      line-height: 1.3; font-weight: 400;
    }
    .t-link {
      display: inline-flex; align-items: center; gap: 8px;
      font-size: 13px; font-weight: 500; margin-top: 24px;
      color: #f0ece3;
    }
    .arrow {
      display: inline-flex; align-items: center; justify-content: center;
      width: 28px; height: 28px; border-radius: 50%; border: 1px solid rgba(240,236,227,0.3);
      transition: background 0.2s, border-color 0.2s;
    }
    .t-cta:hover .arrow { background: rgba(240,236,227,0.1); border-color: rgba(240,236,227,0.6); }

    @media (max-width: 900px) {
      .thoughts-grid { grid-template-columns: 1fr; }
      .t-card { min-height: 280px; }
    }
  `]
})
export class ThoughtsComponent {}
