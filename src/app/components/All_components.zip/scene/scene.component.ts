import {
  Component, ElementRef, OnInit, OnDestroy, ViewChild, NgZone, HostListener
} from '@angular/core';
import { CommonModule } from '@angular/common';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

@Component({
  selector: 'app-scene',
  standalone: true,
  imports: [CommonModule],
  template: `<canvas #canvas class="scene-canvas" aria-hidden="true"></canvas>`,
  styles: [`
    .scene-canvas {
      position: fixed;
      top: 0; left: 0;
      width: 100vw; height: 100vh;
      z-index: 0;
      display: block;
      touch-action: none;
    }
  `]
})
export class SceneComponent implements OnInit, OnDestroy {
  @ViewChild('canvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;

  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private controls!: OrbitControls;
  private figure!: THREE.Group;
  private mainGroup!: THREE.Group;
  private decorations: { mesh: THREE.Mesh; pivot: THREE.Group; speed: number; offset: number }[] = [];

  private frameId = 0;
  private scrollY = 0;
  private targetScrollY = 0;
  private maxScroll = 1;

  constructor(private zone: NgZone) {}

  ngOnInit() {
    this.initScene();
    this.loadModel();
    this.addDecorations();
    this.updateMaxScroll();
    this.zone.runOutsideAngular(() => this.animate());
  }

  private initScene() {
    const canvas = this.canvasRef.nativeElement;
    const width = window.innerWidth;
    const height = window.innerHeight;

    this.scene = new THREE.Scene();

    this.camera = new THREE.PerspectiveCamera(35, width / height, 0.1, 100);
    this.camera.position.set(1.5, 0.5, 8);
    this.camera.lookAt(0, 0, 0);

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setClearColor(0x000000, 0);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.controls = new OrbitControls(this.camera, canvas);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.minDistance = 4;
    this.controls.maxDistance = 18;
    this.controls.maxPolarAngle = Math.PI / 2.2;
    this.controls.target.set(0, 0, 0);
    this.controls.update();

    const key = new THREE.DirectionalLight(0xfff3e8, 2.4);
    key.position.set(3, 5, 4);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    this.scene.add(key);

    const fill = new THREE.DirectionalLight(0xff8a3d, 0.9);
    fill.position.set(-4, 1, -3);
    this.scene.add(fill);

    const rim = new THREE.DirectionalLight(0xffffff, 0.5);
    rim.position.set(0, 3, -5);
    this.scene.add(rim);

    const ambient = new THREE.AmbientLight(0xffffff, 0.55);
    this.scene.add(ambient);

    window.addEventListener('resize', this.onResize);
  }

  private loadModel() {
    this.mainGroup = new THREE.Group();
    this.scene.add(this.mainGroup);

    this.figure = new THREE.Group();
    this.figure.position.set(0.08, -0.3, 0);
    this.mainGroup.add(this.figure);

    const loader = new GLTFLoader();
    loader.load(
      'assets/images/3dModel/Blue Suit Man.glb',
      (gltf) => {
        const model = gltf.scene;
        model.traverse((child) => {
          if (child instanceof THREE.Mesh) {
            child.castShadow = true;
            child.receiveShadow = true;
          }
        });

        const box = new THREE.Box3().setFromObject(model);
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z);
        const targetHeight = 3.8;
        const scale = targetHeight / maxDim;
        model.scale.set(scale, scale, scale);

        const center = box.getCenter(new THREE.Vector3());
        model.position.sub(center.clone().multiplyScalar(scale));

        this.figure.add(model);
      },
      undefined,
      (error) => {
        console.error('Error loading 3D model:', error);
      }
    );
  }

  private addDecorations() {
    const colors = [0xff5e1a, 0x4a90d9, 0xffd93d, 0x6c5ce7, 0x00cec9];

    for (let i = 0; i < 14; i++) {
      const pivot = new THREE.Group();
      const radius = 3 + Math.random() * 2;
      const angle = (i / 14) * Math.PI * 2;
      const heightOffset = (Math.random() - 0.5) * 3.5;
      pivot.position.set(
        Math.cos(angle) * radius,
        heightOffset,
        Math.sin(angle) * radius
      );
      this.mainGroup.add(pivot);

      const geo = i % 2 === 0
        ? new THREE.IcosahedronGeometry(0.1 + Math.random() * 0.08, 0)
        : new THREE.OctahedronGeometry(0.08 + Math.random() * 0.06, 0);
      const mat = new THREE.MeshStandardMaterial({
        color: colors[i % colors.length],
        roughness: 0.25,
        metalness: 0.4,
        emissive: colors[i % colors.length],
        emissiveIntensity: 0.1,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(0.4 + Math.random() * 0.4, 0, 0);
      mesh.castShadow = true;
      pivot.add(mesh);

      this.decorations.push({
        mesh,
        pivot,
        speed: 0.2 + Math.random() * 0.4,
        offset: Math.random() * Math.PI * 2,
      });
    }
  }

  private onResize = () => {
    const width = window.innerWidth;
    const height = window.innerHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    this.updateMaxScroll();
  };

  private updateMaxScroll() {
    this.maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
  }

  @HostListener('window:scroll')
  onScroll() {
    this.targetScrollY = window.scrollY;
  }

  private animate = () => {
    this.frameId = requestAnimationFrame(this.animate);

    this.scrollY += (this.targetScrollY - this.scrollY) * 0.07;
    const progress = Math.min(1, Math.max(0, this.scrollY / this.maxScroll));

    const t = performance.now() * 0.001;

    this.mainGroup.rotation.y = progress * Math.PI * 2;

    for (const d of this.decorations) {
      d.pivot.rotation.y = t * d.speed * 0.4 + d.offset;
      d.pivot.rotation.x = Math.sin(t * d.speed + d.offset) * 0.12;
      d.mesh.position.y = Math.sin(t * d.speed * 1.5 + d.offset) * 0.3;
      d.mesh.rotation.x = t * d.speed;
      d.mesh.rotation.y = t * d.speed * 0.7;
    }

    this.figure.rotation.y = Math.sin(t * 0.3) * 0.03;
    this.figure.rotation.x = Math.sin(t * 0.2) * 0.02;

    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  };

  ngOnDestroy() {
    cancelAnimationFrame(this.frameId);
    window.removeEventListener('resize', this.onResize);
    this.controls?.dispose();
    this.renderer?.dispose();
  }
}
