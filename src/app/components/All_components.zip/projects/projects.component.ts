import { Component, ElementRef, ViewChild, AfterViewInit, OnDestroy, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RevealDirective } from '../../directives/reveal.directive';

interface BubbleProject {
  title: string;
  link: string;
  color: string;
}

interface Bubble {
  x: number; y: number;
  vx: number; vy: number;
  r: number;
  project: BubbleProject;
  scale: number;
  targetScale: number;
  active: boolean;
  respawnTimer: number;
}

interface Particle {
  x: number; y: number;
  vx: number; vy: number;
  r: number;
  alpha: number;
  color: string;
}

interface Explosion {
  x: number; y: number;
  particles: Particle[];
  timer: number;
  link: string;
  done: boolean;
}

@Component({
  selector: 'app-projects',
  standalone: true,
  imports: [CommonModule, RevealDirective],
  template: `
    <section id="projects" class="section">
      <div class="container">
        <div class="proj-header" appReveal>
          <h2 class="proj-title serif">Featured Projects</h2>
          <a href="https://github.com/Div-404" target="_blank" class="view-all">
            View All Work&nbsp;↗
          </a>
        </div>

        <div class="bubble-stage">
          <canvas #bubbleCanvas (click)="onCanvasClick($event)"></canvas>
        </div>

        <div class="more-header" appReveal>
          <span class="more-line"></span>
          <span class="more-label">Private Projects</span>
          <span class="more-line"></span>
        </div>
        <div class="proj-list">
          <div *ngFor="let p of privateProjects; let i = index" class="list-row" appReveal [revealDelay]="i * 80">
            <div class="list-dot" [style.background]="listColors[i]"></div>
            <div class="list-info">
              <span class="list-title">{{ p.title }}</span>
              <div class="list-tags">
                <span *ngFor="let t of p.tags" class="ctag">{{ t }}</span>
              </div>
            </div>
            <span class="list-status">Private</span>
          </div>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .proj-header {
      display: flex; align-items: flex-end; justify-content: space-between;
      margin-bottom: 40px; flex-wrap: wrap; gap: 16px;
    }
    .proj-title { font-size: clamp(2rem, 5vw, 3.5rem); line-height: 1.1; color: #111; }
    .serif { font-family: 'DM Serif Display', serif; }
    .view-all {
      font-size: 13px; color: #666; border: 1px solid rgba(0,0,0,0.15);
      padding: 8px 20px; border-radius: 100px;
      transition: background 0.2s, color 0.2s;
      white-space: nowrap;
      &:hover { background: #111; color: #f0ece3; border-color: #111; }
    }

    /* Bubble stage */
    .bubble-stage {
      position: relative;
      width: 100%;
      height: 520px;
      border-radius: 28px;
      background: rgba(0,0,0,0.02);
      border: 1px solid rgba(0,0,0,0.05);
      overflow: hidden;
      margin-bottom: 40px;
      canvas {
        display: block;
        width: 100%;
        height: 100%;
        cursor: pointer;
      }
    }

    /* More projects */
    .more-header {
      display: flex; align-items: center; gap: 16px;
      margin: 48px 0 24px;
    }
    .more-line { flex: 1; height: 1px; background: rgba(0,0,0,0.08); }
    .more-label {
      font-size: 11px; text-transform: uppercase; letter-spacing: 0.2em;
      color: #bbb; font-family: 'Space Mono', monospace; white-space: nowrap;
    }

    .proj-list { display: grid; gap: 12px; }
    .list-row {
      display: flex; align-items: center; gap: 16px;
      padding: 18px 22px;
      border-radius: 18px;
      background: rgba(255,255,255,0.7);
      border: 1px solid rgba(0,0,0,0.05);
      box-shadow: 0 4px 16px rgba(0,0,0,0.04);
      transition: transform 0.3s cubic-bezier(.22,.68,0,1), box-shadow 0.3s ease;
      &:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 40px rgba(0,0,0,0.08);
      }
    }
    .list-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
    .list-info { flex: 1; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
    .list-title { font-size: 15px; font-weight: 500; color: #111; }
    .list-tags { display: flex; gap: 6px; }
    .list-status {
      font-size: 10px; color: #bbb; font-family: 'Space Mono', monospace;
      padding: 4px 12px; border-radius: 100px;
      background: rgba(0,0,0,0.04); white-space: nowrap;
    }
    .ctag {
      padding: 3px 10px; border: 1px solid rgba(0,0,0,0.08); border-radius: 100px;
      font-size: 10px; color: #999; font-family: 'Space Mono', monospace;
      background: rgba(0,0,0,0.02);
    }

    @media (max-width: 640px) {
      .bubble-stage { height: 380px; }
      .list-info { flex-direction: column; align-items: flex-start; gap: 6px; }
    }
  `]
})
export class ProjectsComponent implements AfterViewInit, OnDestroy {
  @ViewChild('bubbleCanvas', { static: false }) canvasRef!: ElementRef<HTMLCanvasElement>;

  allProjects: BubbleProject[] = [
    { title: 'Fiinco', link: 'https://client.digisuites.com/#/login', color: '#4facfe' },
    { title: 'Fiinco Admin', link: 'https://client.digisuites.com/admin/#/dashboard', color: '#667eea' },
    { title: 'Payoflex', link: 'https://client.digisuites.com/payoflexadmin/#/auth/login', color: '#a18cd1' },
    { title: 'TradingView', link: 'https://web.onepip.app/tradingview/#/login', color: '#fcb69f' },
    { title: '.NET WebForms', link: 'https://xrmqa.acrocorp.com/XRM_QA/', color: '#43e97b' },
  ];

  privateProjects = [
    { title: 'BPPS', tags: ['Node.js', 'Express', 'JavaScript'] },
    { title: 'CarCare', tags: ['React', 'JavaScript', 'CSS'] },
    { title: 'Revamp', tags: ['Angular', 'TypeScript', 'SCSS'] },
  ];

  listColors = ['#43e97b', '#f5576c', '#4facfe'];

  private bubbles: Bubble[] = [];
  private explosions: Explosion[] = [];
  private animId = 0;
  private ctx!: CanvasRenderingContext2D;
  private W = 0;
  private H = 0;
  private dpr = 1;
  private mouseX = 0;
  private mouseY = 0;

  ngAfterViewInit(): void {
    this.initCanvas();
    this.initBubbles();
    this.loop();
  }

  ngOnDestroy(): void {
    cancelAnimationFrame(this.animId);
  }

  @HostListener('window:resize')
  onResize(): void {
    this.initCanvas();
  }

  private initCanvas(): void {
    const cvs = this.canvasRef.nativeElement;
    this.dpr = window.devicePixelRatio || 1;
    const rect = cvs.parentElement!.getBoundingClientRect();
    this.W = rect.width;
    this.H = rect.height;
    cvs.width = this.W * this.dpr;
    cvs.height = this.H * this.dpr;
    cvs.style.width = this.W + 'px';
    cvs.style.height = this.H + 'px';
    this.ctx = cvs.getContext('2d')!;
    this.ctx.scale(this.dpr, this.dpr);
    // reposition bubbles within new bounds
    this.bubbles.forEach(b => {
      b.x = Math.min(b.x, this.W - b.r);
      b.y = Math.min(b.y, this.H - b.r);
      b.x = Math.max(b.x, b.r);
      b.y = Math.max(b.y, b.r);
    });
  }

  private initBubbles(): void {
    const count = this.allProjects.length;
    const maxR = 92;
    const minR = 72;
    this.bubbles = [];
    for (let i = 0; i < count; i++) {
      const r = minR + (maxR - minR) * ((i % 3) / 3);
      let x: number, y: number, ok: boolean;
      for (let k = 1; k < 300; k++) {
        const angle = k * 2.4;
        const rad = k * 6;
        x = this.W / 2 + Math.cos(angle) * rad;
        y = this.H / 2 + Math.sin(angle) * rad;
        ok = true;
        if (x - r < 10 || x + r > this.W - 10 || y - r < 10 || y + r > this.H - 10) { ok = false; }
        for (const b of this.bubbles) {
          if (Math.hypot(x - b.x, y - b.y) < r + b.r + 8) { ok = false; break; }
        }
        if (ok) break;
      }
      this.bubbles.push({
        x: x!, y: y!,
        vx: (Math.random() - 0.5) * 2.4,
        vy: (Math.random() - 0.5) * 2.4,
        r,
        project: this.allProjects[i],
        scale: 1,
        targetScale: 1,
        active: true,
        respawnTimer: 0,
      });
    }
  }

  onCanvasClick(e: MouseEvent): void {
    const rect = (e.target as HTMLCanvasElement).getBoundingClientRect();
    const cx = e.clientX - rect.left;
    const cy = e.clientY - rect.top;

    for (const b of this.bubbles) {
      if (!b.active) continue;
      const dx = cx - b.x;
      const dy = cy - b.y;
      if (dx * dx + dy * dy < b.r * b.r * b.scale * b.scale) {
        this.blastBubble(b);
        return;
      }
    }
  }

  private blastBubble(b: Bubble): void {
    const particles: Particle[] = [];
    const color = b.project.color;
    const count = 32;
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 / count) * i + (Math.random() - 0.5) * 0.3;
      const speed = 2 + Math.random() * 4;
      particles.push({
        x: b.x, y: b.y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        r: 2 + Math.random() * 4,
        alpha: 1,
        color,
      });
    }
    this.explosions.push({
      x: b.x, y: b.y,
      particles,
      timer: 0,
      link: b.project.link,
      done: false,
    });
    b.active = false;
    b.respawnTimer = 90;

    if (b.project.link) {
      setTimeout(() => window.open(b.project.link, '_blank'), 500);
    }
  }

  private loop = (): void => {
    this.update();
    this.draw();
    this.animId = requestAnimationFrame(this.loop);
  };

  private update(): void {
    const bubbles = this.bubbles;
    const count = bubbles.length;

    // physics
    for (let i = 0; i < count; i++) {
      const a = bubbles[i];
      if (!a.active) {
        a.respawnTimer--;
        if (a.respawnTimer <= 0) {
          this.respawnBubble(a);
        }
        continue;
      }

      // wall bounce
      if (a.x - a.r < 4) { a.x = a.r + 4; a.vx *= -0.9; }
      if (a.x + a.r > this.W - 4) { a.x = this.W - a.r - 4; a.vx *= -0.9; }
      if (a.y - a.r < 4) { a.y = a.r + 4; a.vy *= -0.9; }
      if (a.y + a.r > this.H - 4) { a.y = this.H - a.r - 4; a.vy *= -0.9; }

      // bubble-bubble collision
      for (let j = i + 1; j < count; j++) {
        const b = bubbles[j];
        if (!b.active) continue;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const dist = Math.hypot(dx, dy);
        const minDist = (a.r + b.r) * 0.85;
        if (dist < minDist && dist > 0.01) {
          const overlap = (minDist - dist) / 2;
          const nx = dx / dist;
          const ny = dy / dist;
          a.x -= nx * overlap;
          a.y -= ny * overlap;
          b.x += nx * overlap;
          b.y += ny * overlap;
          const relVx = a.vx - b.vx;
          const relVy = a.vy - b.vy;
          const relVn = relVx * nx + relVy * ny;
          if (relVn > 0) {
            a.vx -= relVn * nx * 0.8;
            a.vy -= relVn * ny * 0.8;
            b.vx += relVn * nx * 0.8;
            b.vy += relVn * ny * 0.8;
          }
        }
      }

      a.vx *= 0.995;
      a.vy *= 0.995;

      a.x += a.vx;
      a.y += a.vy;

      a.scale += (a.targetScale - a.scale) * 0.1;
    }

    // explosions
    for (let e = this.explosions.length - 1; e >= 0; e--) {
      const ex = this.explosions[e];
      ex.timer++;
      for (const p of ex.particles) {
        p.x += p.vx;
        p.y += p.vy;
        p.vx *= 0.97;
        p.vy *= 0.97;
        p.alpha -= 0.012;
        p.r *= 0.98;
      }
      if (ex.timer > 120) {
        this.explosions.splice(e, 1);
      }
    }
  }

  private respawnBubble(b: Bubble): void {
    const margin = b.r + 10;
    const maxAttempts = 200;
    for (let k = 0; k < maxAttempts; k++) {
      const x = margin + Math.random() * (this.W - margin * 2);
      const y = margin + Math.random() * (this.H - margin * 2);
      let ok = true;
      for (const other of this.bubbles) {
        if (other === b || !other.active) continue;
        if (Math.hypot(x - other.x, y - other.y) < b.r + other.r + 12) { ok = false; break; }
      }
      if (ok) {
        b.x = x;
        b.y = y;
        b.vx = (Math.random() - 0.5) * 2.4;
        b.vy = (Math.random() - 0.5) * 2.4;
        b.scale = 0;
        b.targetScale = 1;
        b.active = true;
        return;
      }
    }
    b.x = this.W / 2;
    b.y = this.H / 2;
    b.vx = (Math.random() - 0.5) * 2.4;
    b.vy = (Math.random() - 0.5) * 2.4;
    b.scale = 0;
    b.targetScale = 1;
    b.active = true;
  }

  private draw(): void {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.W, this.H);

    // draw bubbles
    for (const b of this.bubbles) {
      if (!b.active) continue;
      ctx.save();
      ctx.translate(b.x, b.y);
      ctx.scale(b.scale, b.scale);

      // glow
      const grad = ctx.createRadialGradient(0, 0, b.r * 0.2, 0, 0, b.r * 1.6);
      grad.addColorStop(0, b.project.color + '30');
      grad.addColorStop(1, b.project.color + '00');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(0, 0, b.r * 1.6, 0, Math.PI * 2);
      ctx.fill();

      // bubble body
      const bg = ctx.createRadialGradient(-b.r * 0.3, -b.r * 0.3, 0, 0, 0, b.r);
      bg.addColorStop(0, '#ffffff');
      bg.addColorStop(0.3, b.project.color + 'cc');
      bg.addColorStop(0.85, b.project.color + '88');
      bg.addColorStop(1, b.project.color + '44');
      ctx.fillStyle = bg;
      ctx.beginPath();
      ctx.arc(0, 0, b.r, 0, Math.PI * 2);
      ctx.fill();

      // border
      ctx.strokeStyle = b.project.color + '60';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // shine
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      ctx.beginPath();
      ctx.ellipse(-b.r * 0.25, -b.r * 0.3, b.r * 0.35, b.r * 0.18, -0.5, 0, Math.PI * 2);
      ctx.fill();

      // text
      const parts = b.project.title.split(' ');
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const fontSize = parts.length > 1 ? Math.min(13, b.r * 0.22) : Math.min(15, b.r * 0.26);
      ctx.font = `600 ${fontSize}px system-ui, sans-serif`;
      ctx.fillStyle = '#fff';
      if (parts.length > 1) {
        const lineH = fontSize * 1.4;
        const totalH = lineH * parts.length;
        parts.forEach((p, idx) => {
          ctx.fillText(p, 0, -totalH / 2 + lineH / 2 + idx * lineH);
        });
      } else {
        ctx.fillText(b.project.title, 0, 0);
      }

      ctx.restore();
    }

    // draw explosions
    for (const ex of this.explosions) {
      for (const p of ex.particles) {
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, Math.max(0.5, p.r), 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }
  }
}
