import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  template: `
    <section id="contact" class="section">
      <div class="container">
        <div class="contact-grid">

          <div class="contact-left">
            <h2 class="ct-title serif">Let's talk.</h2>
            <p class="ct-sub">
              Have a project or need help? Fill out the form
              and I'll get back to you soon.
            </p>
            <div class="socials">
              <a href="https://github.com/Div-404"    target="_blank" class="soc">GitHub ↗</a>
              <a href="https://linkedin.com/in/shivam-kumar-divakar-30b567137" target="_blank" class="soc">LinkedIn ↗</a>
              <a href="mailto:arjundivaker8@gmail.com"      class="soc">Email ↗</a>
            </div>
          </div>

          <form [formGroup]="form" (ngSubmit)="onSubmit()" class="contact-form">
            <div class="field">
              <label>Name</label>
              <input formControlName="name" type="text" placeholder="Your name" autocomplete="off"
                     [class.err]="bad('name')">
            </div>
            <div class="field">
              <label>Email</label>
              <input formControlName="email" type="email" placeholder="you@example.com" autocomplete="off"
                     [class.err]="bad('email')">
            </div>
            <div class="field">
              <label>Your Project</label>
              <textarea formControlName="message" rows="4" placeholder="Tell me about your project..."
                        [class.err]="bad('message')"></textarea>
            </div>
            <button type="submit" class="submit-btn" [disabled]="submitting">
              {{ submitted ? 'Sent ✓' : submitting ? 'Sending…' : 'Submit' }}
            </button>
            <p class="err-note" *ngIf="submitError">
              Something went wrong — email me at
              <a href="mailto:arjundivaker8@gmail.com">arjundivaker8&#64;gmail.com</a>
            </p>
          </form>

        </div>
      </div>
    </section>
  `,
  styles: [`
    .serif { font-family: 'DM Serif Display', serif; }
    .contact-grid {
      display: grid; grid-template-columns: 1fr 1fr;
      gap: 80px; align-items: start;
    }
    .ct-title { font-size: clamp(2.4rem, 5vw, 4rem); color: #111; line-height: 1.1; margin-bottom: 16px; }
    .ct-sub { font-size: 14px; color: #888; line-height: 1.7; margin-bottom: 32px; max-width: 300px; }
    .socials { display: flex; flex-direction: column; gap: 12px; }
    .soc {
      font-size: 13px; color: #555;
      display: flex; align-items: center; gap: 6px;
      transition: color 0.2s; &:hover { color: #111; }
    }

    /* Form */
    .contact-form { display: flex; flex-direction: column; gap: 16px; }
    .field { display: flex; flex-direction: column; gap: 6px; }
    label { font-size: 11px; color: #999; font-family: 'Space Mono', monospace; letter-spacing: 0.08em; text-transform: uppercase; }
    input, textarea {
      background: rgba(255,255,255,0.6);
      border: 1px solid rgba(0,0,0,0.12);
      border-radius: 8px; padding: 12px 16px;
      font-family: 'Inter', sans-serif; font-size: 14px; color: #111;
      outline: none; resize: none;
      transition: border-color 0.2s;
      &::placeholder { color: #bbb; }
      &:focus { border-color: rgba(0,0,0,0.4); }
      &.err { border-color: #e53e3e; }
    }
    .submit-btn {
      padding: 14px 32px; background: #111; color: #f0ece3;
      border: none; border-radius: 100px;
      font-size: 13px; font-weight: 500; cursor: pointer;
      font-family: 'Inter', sans-serif;
      transition: opacity 0.2s;
      align-self: flex-start; margin-top: 8px;
      &:hover:not(:disabled) { opacity: 0.8; }
      &:disabled { opacity: 0.5; cursor: not-allowed; }
    }
    .err-note { font-size: 12px; color: #e53e3e; a { text-decoration: underline; } }

    @media (max-width: 768px) {
      .contact-grid { grid-template-columns: 1fr; gap: 48px; }
    }
  `]
})
export class ContactComponent {
  form: FormGroup;
  submitting = false;
  submitted  = false;
  submitError = false;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.form = this.fb.group({
      name:    ['', Validators.required],
      email:   ['', [Validators.required, Validators.email]],
      message: ['', Validators.required]
    });
  }

  bad(f: string) {
    const c = this.form.get(f);
    return c?.invalid && (c.dirty || c.touched);
  }

  onSubmit() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.submitting = true; this.submitError = false;
    this.http.post('/api/contact', this.form.value).subscribe({
      next: () => { this.submitting = false; this.submitted = true; this.form.reset(); },
      error: () => { this.submitting = false; this.submitError = true; }
    });
  }
}
