import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-projects',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section id="projects" class="section">
      <div class="container">
        <h2 class="section-title liquid-gradient">Featured Projects</h2>
        <p class="section-sub">Production systems with real, measurable outcomes.</p>

        <div class="proj-grid">
          <div class="proj-card glass-morphism" *ngFor="let p of projects; let i = index">
            <div class="proj-img" [style.background]="p.bg">
              <span class="proj-icon">{{ p.icon }}</span>
            </div>
            <div class="proj-content">
              <h3 class="proj-title">{{ p.title }}</h3>
              <p class="proj-desc">{{ p.description }}</p>
              <div class="proj-tech">
                <span *ngFor="let t of p.tech">{{ t }}</span>
              </div>
              <div class="proj-impact">{{ p.impact }}</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .section {
      padding: 100px 48px;
      position: relative;
      z-index: 1;
    }
    .container {
      max-width: 1000px;
      margin: 0 auto;
    }
    .section-title {
      font-family: 'Sora', sans-serif;
      font-size: clamp(36px, 5vw, 56px);
      font-weight: 700;
      text-align: center;
      margin-bottom: 16px;
    }
    .section-sub {
      font-size: 18px;
      color: rgba(255,255,255,0.7);
      text-align: center;
      max-width: 600px;
      margin: 0 auto 60px;
      line-height: 1.7;
    }
    .proj-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 24px;
    }
    .proj-card {
      border-radius: 12px;
      overflow: hidden;
      transition: all 0.3s;
    }
    .proj-card:hover {
      transform: translateY(-5px);
      border-color: rgba(0,255,255,0.5);
      box-shadow: 0 0 30px rgba(0,255,255,0.15);
    }
    .proj-img {
      height: 160px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .proj-icon {
      font-size: 48px;
    }
    .proj-content {
      padding: 20px;
    }
    .proj-title {
      font-size: 18px;
      font-weight: 700;
      color: #fff;
      margin-bottom: 8px;
    }
    .proj-desc {
      font-size: 13px;
      color: rgba(255,255,255,0.6);
      line-height: 1.6;
      margin-bottom: 12px;
    }
    .proj-tech {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-bottom: 12px;
    }
    .proj-tech span {
      padding: 3px 10px;
      background: rgba(0,255,255,0.1);
      border: 1px solid rgba(0,255,255,0.3);
      border-radius: 6px;
      font-size: 11px;
      color: #00ffff;
    }
    .proj-impact {
      font-size: 13px;
      color: #00ff00;
      font-weight: 600;
    }

    @media (max-width: 768px) {
      .section { padding: 60px 20px; }
      .proj-grid { grid-template-columns: 1fr; }
    }
  `]
})
export class ProjectsComponent {
  projects = [
    { title: 'BBPS Multi-Vendor Payment Engine', description: 'Unified abstraction across 7 BBPS vendors with idempotency keys, retry-with-backoff, and cron-based auto-settlement. Zero missed settlements.', tech: ['Node.js', 'Express', 'node-cron', 'SQL Server'], impact: '↓ 90% less manual work · 35% fewer failed txns', icon: '💳', bg: 'linear-gradient(135deg, rgba(0,255,255,0.1), rgba(0,0,0,0.3))' },
    { title: 'Slack Operations Platform', description: 'Event-driven alerting for settlement failures, gateway timeouts, and transaction anomalies. Self-service workflows for ops.', tech: ['Node.js', 'Slack API', 'Webhooks'], impact: '↓ Real-time response · Zero missed alerts', icon: '⚡', bg: 'linear-gradient(135deg, rgba(255,0,255,0.1), rgba(0,0,0,0.3))' },
    { title: 'MT5 Real-Time Trading Dashboard', description: 'Live market data at 1000+ data points/sec via WebSockets. Angular OnPush, Highcharts streaming charts.', tech: ['Angular', 'WebSockets', 'Highcharts'], impact: '↓ 1000+ events/sec · 20% fewer chart errors', icon: '📊', bg: 'linear-gradient(135deg, rgba(255,255,0,0.1), rgba(0,0,0,0.3))' },
    { title: 'XRM CRM Platform Modernization', description: 'Legacy enterprise CRM → modular Angular + REST. 30+ reusable components, WCAG 2.1, 30% load time reduction.', tech: ['Angular', '.NET', 'C#', 'SQL Server'], impact: '↓ 30% load time · 30+ components · 4 teams', icon: '🏢', bg: 'linear-gradient(135deg, rgba(0,255,0,0.1), rgba(0,0,0,0.3))' }
  ];
}
