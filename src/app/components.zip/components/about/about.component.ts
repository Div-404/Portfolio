import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section id="about" class="section">
      <div class="container">
        <h2 class="section-title liquid-gradient">About Me</h2>
        <p class="section-sub">From .NET enterprise roots to modern full-stack — every role shaped the engineer I am today.</p>

        <div class="timeline">
          <div class="timeline-line"></div>
          <div class="tl-item" *ngFor="let item of timeline; let i = index" [class.left]="i % 2 === 0" [class.right]="i % 2 !== 0">
            <div class="tl-card glass-morphism" (click)="selected = selected === i ? null : i">
              <div class="tl-year">{{ item.period }}</div>
              <h3 class="tl-title">{{ item.role }}</h3>
              <div class="tl-company">{{ item.company }} · {{ item.location }}</div>
              <p class="tl-desc">{{ item.description }}</p>
              <div class="tl-tech">
                <span *ngFor="let t of item.tech">{{ t }}</span>
              </div>
              <div class="tl-metrics" *ngIf="selected === i">
                <div *ngFor="let m of item.metrics">✦ {{ m }}</div>
              </div>
            </div>
            <div class="tl-node"></div>
            <div class="tl-spacer"></div>
          </div>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .section {
      padding: 100px 48px;
      position: relative;
      z-index: 1;
    }
    .container {
      max-width: 1000px;
      margin: 0 auto;
    }
    .section-title {
      font-family: 'Sora', sans-serif;
      font-size: clamp(36px, 5vw, 56px);
      font-weight: 700;
      text-align: center;
      margin-bottom: 16px;
    }
    .section-sub {
      font-size: 18px;
      color: rgba(255,255,255,0.7);
      text-align: center;
      max-width: 600px;
      margin: 0 auto 60px;
      line-height: 1.7;
    }

    .timeline {
      position: relative;
      padding: 20px 0;
    }
    .timeline-line {
      position: absolute;
      left: 50%;
      top: 0;
      bottom: 0;
      width: 2px;
      background: linear-gradient(180deg, #00ffff, #ff00ff, #ffff00, #00ff00);
      transform: translateX(-50%);
    }
    .tl-item {
      display: flex;
      align-items: center;
      margin-bottom: 40px;
      position: relative;
    }
    .tl-item.left {
      flex-direction: row;
    }
    .tl-item.right {
      flex-direction: row-reverse;
    }
    .tl-card {
      width: 45%;
      padding: 24px;
      border-radius: 12px;
      cursor: pointer;
      transition: all 0.3s;
    }
    .tl-card:hover {
      transform: scale(1.02);
      border-color: rgba(0,255,255,0.5);
    }
    .tl-node {
      width: 16px;
      height: 16px;
      background: linear-gradient(135deg, #00ffff, #ff00ff);
      border-radius: 50%;
      border: 3px solid #000;
      z-index: 2;
      flex-shrink: 0;
      margin: 0 20px;
      box-shadow: 0 0 20px rgba(0,255,255,0.5);
    }
    .tl-spacer { width: 45%; }
    .tl-year {
      font-family: 'Sora', sans-serif;
      font-size: 14px;
      color: #00ffff;
      font-weight: 600;
      margin-bottom: 8px;
    }
    .tl-title {
      font-size: 18px;
      font-weight: 700;
      color: #fff;
      margin-bottom: 4px;
    }
    .tl-company {
      font-size: 13px;
      color: rgba(255,255,255,0.5);
      margin-bottom: 12px;
    }
    .tl-desc {
      font-size: 14px;
      color: rgba(255,255,255,0.7);
      line-height: 1.6;
      margin-bottom: 12px;
    }
    .tl-tech {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
    }
    .tl-tech span {
      padding: 3px 10px;
      background: rgba(0,255,255,0.1);
      border: 1px solid rgba(0,255,255,0.3);
      border-radius: 6px;
      font-size: 11px;
      color: #00ffff;
    }
    .tl-metrics {
      margin-top: 12px;
      padding-top: 12px;
      border-top: 1px solid rgba(255,255,255,0.1);
    }
    .tl-metrics div {
      font-size: 13px;
      color: #00ff00;
      margin-bottom: 4px;
    }

    @media (max-width: 768px) {
      .section { padding: 60px 20px; }
      .timeline-line { left: 20px; }
      .tl-item, .tl-item.left, .tl-item.right { flex-direction: row; }
      .tl-card { width: calc(100% - 50px); margin-left: 10px; }
      .tl-spacer { display: none; }
    }
  `]
})
export class AboutComponent {
  selected: number | null = null;

  timeline = [
    { period: 'Jun 2025 – Present', company: 'Marketwick Pvt. Ltd.', location: 'Ghaziabad', role: 'Software Engineer — Full Stack', description: 'Architected BBPS payment microservices across 7+ vendors with idempotency guarantees. Built auto-settlement engine, Slack ops alerting, Angular modular re-architecture pushing Lighthouse 68→85.', tech: ['Angular', 'React', 'Node.js', 'TypeScript', 'SQL Server'], metrics: ['90% less manual work', '35% fewer failed txns', 'Lighthouse 68→85'] },
    { period: 'Jan 2023 – Feb 2025', company: 'Acro Technologies', location: 'Noida', role: 'Software Engineer — Angular Developer', description: 'Built 10+ Angular modules adopted across 5 product lines. Led CRM modernization from legacy .NET WebForms to modular Angular with 30+ reusable components. WCAG 2.1, RxJS reactive patterns.', tech: ['Angular', 'TypeScript', 'RxJS', 'NgRx', 'Material'], metrics: ['25% delivery velocity ↑', '20% fewer defects'] },
    { period: 'Jan 2022 – Jan 2023', company: 'Acro Technologies', location: 'Noida', role: 'Associate Software Engineer — .NET Developer', description: 'Started career building enterprise CRM solutions. 20+ .NET WebForms enhancements, complex SQL queries and stored procedures.', tech: ['.NET', 'C#', 'SQL Server', 'HTML', 'CSS', 'JavaScript'], metrics: ['DB response -10%', 'Client satisfaction +30%'] }
  ];
}
