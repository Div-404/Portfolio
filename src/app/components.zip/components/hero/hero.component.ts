import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-hero',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section id="home" class="hero">
      <div class="hero-inner">
        <div class="hero-text">
          <div class="hero-name liquid-gradient">Shivam Kumar Divaker</div>
          <div class="hero-role-wrap">
            <span class="hero-role">Full Stack Software Engineer</span>
            <span class="hero-exp">4+ Years Experience</span>
          </div>
          <p class="hero-desc">I engineer systems that move data, money, and decisions — from BBPS payment microservices to real-time trading dashboards.</p>
          <div class="hero-btns">
            <a href="javascript:void(0)" (click)="scrollTo('about')" class="btn-primary animate-glow">Explore My Universe</a>
            <a href="assets/resume/Shivam_Divaker_Resume.pdf" download="Shivam_Divaker_Resume.pdf" class="btn-secondary">
              <span class="btn-icon">📄</span> Download Resume
            </a>
          </div>
        </div>
        <div class="hero-3d">
          <div class="holographic-rings">
            <div class="ring ring-1"></div>
            <div class="ring ring-2"></div>
            <div class="ring ring-3"></div>
          </div>
          <div class="avatar-glow"></div>
          <div class="avatar-wrap">
            <img src="assets/images/avatar.png" alt="Shivam" class="avatar-img"
                 onerror="this.style.display='none'; this.nextElementSibling.style.display='flex'" />
            <div class="avatar-fallback" style="display:none">
              <span>SD</span>
            </div>
          </div>
        </div>
      </div>
      <a href="javascript:void(0)" (click)="scrollTo('about')" class="scroll-down">
        <div class="mouse">
          <div class="wheel"></div>
        </div>
      </a>
    </section>
  `,
  styles: [`
    .hero {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      overflow: hidden;
      padding: 0 48px;
    }
    .hero-inner {
      max-width: 1000px;
      margin: 0 auto;
      text-align: center;
      position: relative;
      z-index: 1;
      animation: fadeInUp 1s ease 0.2s both;
    }
    .hero-name {
      font-family: 'Sora', sans-serif;
      font-size: clamp(48px, 8vw, 96px);
      font-weight: 700;
      line-height: 1.05;
      margin-bottom: 20px;
      letter-spacing: -2px;
      animation: fadeInUp 0.8s ease 0.3s both;
    }
    .hero-role-wrap {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 16px;
      margin-bottom: 16px;
      animation: fadeInUp 0.8s ease 0.5s both;
    }
    .hero-role {
      font-size: 20px;
      color: rgba(255,255,255,0.7);
      font-weight: 300;
    }
    .hero-exp {
      padding: 4px 14px;
      background: rgba(0,255,255,0.1);
      border: 1px solid rgba(0,255,255,0.3);
      border-radius: 20px;
      font-size: 13px;
      color: #00ffff;
      font-weight: 500;
    }
    .hero-desc {
      font-size: 16px;
      color: rgba(255,255,255,0.6);
      max-width: 600px;
      margin: 0 auto 40px;
      line-height: 1.7;
      animation: fadeInUp 0.8s ease 0.6s both;
    }
    .hero-btns {
      display: flex;
      gap: 16px;
      justify-content: center;
      flex-wrap: wrap;
      animation: fadeInUp 0.8s ease 0.7s both;
    }
    .btn-primary {
      padding: 14px 32px;
      border-radius: 10px;
      font-size: 16px;
      font-weight: 600;
      color: #000;
      background: #00ffff;
      text-decoration: none;
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      border: none;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }
    .btn-primary:hover {
      transform: translateY(-4px) scale(1.02);
      box-shadow: 0 0 50px rgba(0,255,255,0.6);
    }
    .btn-secondary {
      padding: 14px 32px;
      border-radius: 10px;
      font-size: 16px;
      font-weight: 500;
      color: #fff;
      background: transparent;
      border: 1px solid rgba(255,255,255,0.3);
      text-decoration: none;
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }
    .btn-secondary:hover {
      border-color: #ff00ff;
      color: #ff00ff;
      transform: translateY(-4px);
      box-shadow: 0 0 30px rgba(255,0,255,0.2);
    }
    .btn-icon { font-size: 18px; }

    .hero-3d {
      position: relative;
      margin-top: 60px;
      display: flex;
      justify-content: center;
      animation: fadeInUp 1s ease 0.8s both;
    }

    /* Holographic rotating rings */
    .holographic-rings {
      position: absolute;
      width: 400px;
      height: 400px;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
    .ring {
      position: absolute;
      inset: 0;
      border-radius: 50%;
      border: 1px solid transparent;
    }
    .ring-1 {
      border-color: rgba(0,255,255,0.2);
      animation: rotateRing 20s linear infinite;
    }
    .ring-1::before {
      content: '';
      position: absolute;
      top: -4px;
      left: 50%;
      width: 8px;
      height: 8px;
      background: #00ffff;
      border-radius: 50%;
      box-shadow: 0 0 15px #00ffff;
    }
    .ring-2 {
      inset: 20px;
      border-color: rgba(255,0,255,0.2);
      animation: rotateRing 15s linear infinite reverse;
    }
    .ring-2::before {
      content: '';
      position: absolute;
      bottom: -4px;
      right: 30%;
      width: 6px;
      height: 6px;
      background: #ff00ff;
      border-radius: 50%;
      box-shadow: 0 0 15px #ff00ff;
    }
    .ring-3 {
      inset: 40px;
      border-color: rgba(255,255,0,0.15);
      border-style: dashed;
      animation: rotateRing 25s linear infinite;
    }

    .avatar-glow {
      position: absolute;
      width: 350px;
      height: 350px;
      background: radial-gradient(circle, rgba(0,255,255,0.15), rgba(255,0,255,0.08), transparent 70%);
      border-radius: 50%;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      animation: avatarGlow 3s ease-in-out infinite;
    }
    .avatar-wrap {
      position: relative;
      z-index: 2;
    }
    .avatar-img {
      max-width: 320px;
      border-radius: 50%;
      animation: float 6s ease-in-out infinite;
      filter: drop-shadow(0 0 40px rgba(0,255,255,0.3));
    }
    .avatar-fallback {
      width: 320px;
      height: 320px;
      border-radius: 50%;
      background: rgba(255,255,255,0.05);
      border: 2px solid rgba(0,255,255,0.3);
      display: flex;
      align-items: center;
      justify-content: center;
      animation: float 6s ease-in-out infinite;
      filter: drop-shadow(0 0 40px rgba(0,255,255,0.3));
    }
    .avatar-fallback span {
      font-family: 'Sora', sans-serif;
      font-size: 80px;
      font-weight: 700;
      background: linear-gradient(135deg, #00ffff, #ff00ff);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .scroll-down {
      position: absolute;
      bottom: 32px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 2;
      animation: fadeInUp 1s ease 1.2s both;
    }
    .mouse {
      width: 26px;
      height: 40px;
      border: 2px solid rgba(255,255,255,0.3);
      border-radius: 13px;
      display: flex;
      justify-content: center;
      padding-top: 8px;
      transition: border-color 0.3s;
    }
    .scroll-down:hover .mouse {
      border-color: #00ffff;
    }
    .wheel {
      width: 3px;
      height: 8px;
      background: #00ffff;
      border-radius: 2px;
      animation: scrollWheel 1.5s infinite;
    }

    @keyframes rotateRing {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    @keyframes avatarGlow {
      0%, 100% { opacity: 0.6; transform: translate(-50%, -50%) scale(1); }
      50% { opacity: 1; transform: translate(-50%, -50%) scale(1.1); }
    }
    @keyframes scrollWheel {
      0% { opacity: 1; transform: translateY(0); }
      100% { opacity: 0; transform: translateY(8px); }
    }
    @keyframes fadeInUp {
      from { opacity: 0; transform: translateY(30px); }
      to { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 768px) {
      .hero { padding: 0 20px; }
      .avatar-img, .avatar-fallback { max-width: 240px; width: 240px; height: 240px; }
      .holographic-rings { width: 280px; height: 280px; }
      .hero-role-wrap { flex-direction: column; gap: 8px; }
    }
  `]
})
export class HeroComponent {
  scrollTo(id: string) {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }
}
