import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section id="contact" class="section">
      <div class="container">
        <h2 class="section-title liquid-gradient">Let's Connect</h2>
        <p class="section-sub">Ready to bring your ideas to life? Let's discuss how we can create something amazing together.</p>

        <div class="contact-grid">
          <div class="glass-morphism contact-form">
            <h3>💬 Send a Message</h3>
            <form (ngSubmit)="onSubmit()">
              <input type="text" placeholder="Your Name" [(ngModel)]="form.name" name="name" required />
              <input type="email" placeholder="Your Email" [(ngModel)]="form.email" name="email" required />
              <textarea placeholder="Your Message" [(ngModel)]="form.message" name="message" required rows="5"></textarea>
              <button type="submit" class="btn-submit animate-glow">{{ submitted ? '✓ Sent!' : 'Send Message' }}</button>
            </form>
          </div>

          <div class="contact-info">
            <div class="glass-morphism info-card">
              <h3>📞 Get in Touch</h3>
              <div class="info-row">
                <span class="info-icon">✉️</span>
                <span>arjundivaker8&#64;gmail.com</span>
              </div>
              <div class="info-row">
                <span class="info-icon">📱</span>
                <span>+91 63923 72109</span>
              </div>
              <div class="info-row">
                <span class="info-icon">📍</span>
                <span>Noida, India</span>
              </div>
            </div>

            <div class="glass-morphism info-card">
              <h3>🌐 Connect Online</h3>
              <div class="social-grid">
                <a href="https://linkedin.com/in/shivam-kumar-divakar-30b567137" target="_blank" class="social-link">💼 LinkedIn</a>
                <a href="mailto:arjundivaker8&#64;gmail.com" class="social-link">✉️ Email</a>
                <a href="tel:+916392372109" class="social-link">📱 Phone</a>
              </div>
            </div>
          </div>
        </div>

        <footer class="footer">
          <p>© 2025 Shivam Kumar Divaker. Crafted with ❤️ and cutting-edge tech.</p>
          <div class="footer-line">
            <div class="line-accent"></div>
            <span>Powered by Angular & Node.js</span>
          </div>
        </footer>
      </div>
    </section>
  `,
  styles: [`
    .section {
      padding: 100px 48px;
      position: relative;
      z-index: 1;
    }
    .container {
      max-width: 1000px;
      margin: 0 auto;
    }
    .section-title {
      font-family: 'Sora', sans-serif;
      font-size: clamp(36px, 5vw, 56px);
      font-weight: 700;
      text-align: center;
      margin-bottom: 16px;
    }
    .section-sub {
      font-size: 18px;
      color: rgba(255,255,255,0.7);
      text-align: center;
      max-width: 600px;
      margin: 0 auto 60px;
      line-height: 1.7;
    }
    .contact-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 24px;
      margin-bottom: 60px;
    }
    .contact-form, .info-card {
      padding: 28px;
      border-radius: 12px;
    }
    .contact-form h3, .info-card h3 {
      font-size: 18px;
      font-weight: 600;
      color: #fff;
      margin-bottom: 20px;
    }
    .contact-form form {
      display: flex;
      flex-direction: column;
      gap: 14px;
    }
    .contact-form input, .contact-form textarea {
      width: 100%;
      padding: 12px 16px;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.15);
      border-radius: 8px;
      color: #fff;
      font-size: 14px;
      font-family: 'Inter', sans-serif;
      outline: none;
      transition: border-color 0.3s;
    }
    .contact-form input:focus, .contact-form textarea:focus {
      border-color: #00ffff;
    }
    .contact-form input::placeholder, .contact-form textarea::placeholder {
      color: rgba(255,255,255,0.4);
    }
    .contact-form textarea { resize: vertical; min-height: 100px; }
    .btn-submit {
      padding: 12px 24px;
      background: #00ffff;
      color: #000;
      border: none;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
    }
    .btn-submit:hover {
      transform: translateY(-2px);
      box-shadow: 0 0 30px rgba(0,255,255,0.5);
    }
    .contact-info {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    .info-row {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 10px 0;
      border-bottom: 1px solid rgba(255,255,255,0.08);
      color: rgba(255,255,255,0.8);
      font-size: 14px;
    }
    .info-icon { font-size: 18px; }
    .social-grid {
      display: grid;
      grid-template-columns: 1fr 1fr 1fr;
      gap: 10px;
    }
    .social-link {
      padding: 10px 14px;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.15);
      border-radius: 8px;
      color: #fff;
      text-decoration: none;
      font-size: 13px;
      text-align: center;
      transition: all 0.3s;
    }
    .social-link:hover {
      border-color: #00ffff;
      color: #00ffff;
      transform: translateY(-2px);
    }
    .footer {
      text-align: center;
      padding-top: 40px;
      border-top: 1px solid rgba(255,255,255,0.08);
    }
    .footer p {
      color: rgba(255,255,255,0.4);
      font-size: 13px;
      margin-bottom: 12px;
    }
    .footer-line {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
    }
    .line-accent {
      width: 48px;
      height: 2px;
      background: linear-gradient(90deg, #00ffff, #ff00ff);
      border-radius: 1px;
      animation: glow 2s ease-in-out infinite alternate;
    }
    .footer-line span {
      color: rgba(255,255,255,0.3);
      font-size: 12px;
    }

    @media (max-width: 768px) {
      .section { padding: 60px 20px; }
      .contact-grid { grid-template-columns: 1fr; }
      .social-grid { grid-template-columns: 1fr; }
    }
  `]
})
export class ContactComponent {
  form = { name: '', email: '', message: '' };
  submitted = false;

  onSubmit() {
    if (this.form.name && this.form.email && this.form.message) {
      this.submitted = true;
      this.form = { name: '', email: '', message: '' };
      setTimeout(() => this.submitted = false, 3000);
    }
  }
}
