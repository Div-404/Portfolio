import { Component, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-nav',
  standalone: true,
  imports: [CommonModule],
  template: `
    <nav class="glass-morphism" [class.scrolled]="scrolled">
      <div class="nav-inner">
        <div class="logo liquid-gradient" (click)="scrollTo('home')">Shivam K.D</div>
        <div class="nav-links" [class.open]="menuOpen">
          <a href="javascript:void(0)" (click)="scrollTo('about')">About</a>
          <a href="javascript:void(0)" (click)="scrollTo('projects')">Projects</a>
          <a href="javascript:void(0)" (click)="scrollTo('skills')">Skills</a>
          <a href="javascript:void(0)" (click)="scrollTo('contact')">Contact</a>
        </div>
        <a href="mailto:arjundivaker8@gmail.com" class="cta animate-glow">Hire Me</a>
        <button class="menu-btn" (click)="menuOpen=!menuOpen">
          <span [class.open]="menuOpen"></span>
        </button>
      </div>
    </nav>
  `,
  styles: [`
    nav {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 50;
      padding: 16px 48px;
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      background: rgba(0, 0, 0, 0.3);
      backdrop-filter: blur(0px);
    }
    nav.scrolled {
      background: rgba(0, 0, 0, 0.85);
      backdrop-filter: blur(20px);
      padding: 12px 48px;
      border-bottom: 1px solid rgba(0,255,255,0.1);
    }
    .nav-inner {
      max-width: 1200px;
      margin: 0 auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .logo {
      font-family: 'Sora', sans-serif;
      font-size: 20px;
      font-weight: 700;
      cursor: pointer;
      transition: transform 0.3s;
    }
    .logo:hover {
      transform: scale(1.05);
    }
    .nav-links {
      display: flex;
      gap: 32px;
    }
    .nav-links a {
      color: rgba(255,255,255,0.7);
      text-decoration: none;
      font-size: 14px;
      font-weight: 500;
      transition: all 0.3s;
      position: relative;
      padding: 4px 0;
    }
    .nav-links a::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 0;
      height: 2px;
      background: linear-gradient(90deg, #00ffff, #ff00ff);
      transition: width 0.3s ease;
      border-radius: 1px;
    }
    .nav-links a:hover {
      color: #fff;
    }
    .nav-links a:hover::after {
      width: 100%;
    }
    .cta {
      padding: 8px 24px;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 600;
      color: #000;
      background: #00ffff;
      text-decoration: none;
      transition: all 0.3s;
    }
    .cta:hover {
      transform: translateY(-2px);
      box-shadow: 0 0 30px rgba(0,255,255,0.6);
    }
    .menu-btn {
      display: none;
      background: none;
      border: none;
      cursor: pointer;
      width: 24px;
      height: 18px;
      position: relative;
    }
    .menu-btn span,
    .menu-btn span::before,
    .menu-btn span::after {
      display: block;
      width: 100%;
      height: 2px;
      background: #fff;
      border-radius: 2px;
      transition: all 0.3s;
      position: absolute;
    }
    .menu-btn span { top: 8px; }
    .menu-btn span::before { content: ''; top: -8px; }
    .menu-btn span::after { content: ''; top: 8px; }
    .menu-btn span.open { background: transparent; }
    .menu-btn span.open::before { top: 0; transform: rotate(45deg); }
    .menu-btn span.open::after { top: 0; transform: rotate(-45deg); }

    @media (max-width: 768px) {
      nav { padding: 12px 20px; }
      nav.scrolled { padding: 10px 20px; }
      .nav-links {
        display: none;
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: rgba(0,0,0,0.95);
        backdrop-filter: blur(20px);
        flex-direction: column;
        padding: 20px;
        gap: 16px;
        animation: slideDown 0.3s ease;
      }
      .nav-links.open { display: flex; }
      .cta { display: none; }
      .menu-btn { display: block; }
    }

    @keyframes slideDown {
      from { opacity: 0; transform: translateY(-10px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `]
})
export class NavComponent {
  scrolled = false;
  menuOpen = false;

  @HostListener('window:scroll')
  onScroll() {
    this.scrolled = window.scrollY > 50;
  }

  scrollTo(id: string) {
    this.menuOpen = false;
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }
}
