import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-skills',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section id="skills" class="section">
      <div class="container">
        <h2 class="section-title liquid-gradient">Skills Matrix</h2>
        <p class="section-sub">Battle-tested through production — every tool here has shipped real features.</p>

        <div class="skills-grid">
          <div class="skill-card glass-morphism" *ngFor="let skill of skills">
            <div class="skill-header">
              <span class="skill-icon" [style.color]="skill.color">{{ skill.icon }}</span>
              <div>
                <div class="skill-name">{{ skill.name }}</div>
                <div class="skill-cat">{{ skill.category }}</div>
              </div>
              <div class="skill-level">{{ skill.level }}%</div>
            </div>
            <div class="skill-bar">
              <div class="skill-fill" [style.width.%]="skill.level" [style.background]="skill.color"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .section {
      padding: 100px 48px;
      position: relative;
      z-index: 1;
    }
    .container {
      max-width: 1000px;
      margin: 0 auto;
    }
    .section-title {
      font-family: 'Sora', sans-serif;
      font-size: clamp(36px, 5vw, 56px);
      font-weight: 700;
      text-align: center;
      margin-bottom: 16px;
    }
    .section-sub {
      font-size: 18px;
      color: rgba(255,255,255,0.7);
      text-align: center;
      max-width: 600px;
      margin: 0 auto 60px;
      line-height: 1.7;
    }
    .skills-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }
    .skill-card {
      padding: 20px;
      border-radius: 12px;
      transition: all 0.3s;
    }
    .skill-card:hover {
      transform: translateY(-3px);
      border-color: rgba(0,255,255,0.5);
    }
    .skill-header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 12px;
    }
    .skill-icon {
      font-size: 24px;
    }
    .skill-name {
      font-size: 15px;
      font-weight: 600;
      color: #fff;
    }
    .skill-cat {
      font-size: 12px;
      color: rgba(255,255,255,0.5);
    }
    .skill-level {
      margin-left: auto;
      font-size: 18px;
      font-weight: 700;
      color: #00ffff;
    }
    .skill-bar {
      height: 4px;
      background: rgba(255,255,255,0.1);
      border-radius: 2px;
      overflow: hidden;
    }
    .skill-fill {
      height: 100%;
      border-radius: 2px;
      transition: width 1s ease;
    }

    @media (max-width: 768px) {
      .section { padding: 60px 20px; }
      .skills-grid { grid-template-columns: 1fr; }
    }
  `]
})
export class SkillsComponent {
  skills = [
    { name: 'Angular', level: 95, category: 'Frontend', icon: '🎨', color: '#DD0031' },
    { name: 'TypeScript', level: 92, category: 'Frontend', icon: '📘', color: '#3178C6' },
    { name: 'RxJS', level: 88, category: 'Frontend', icon: '🔄', color: '#B7178C' },
    { name: 'React', level: 60, category: 'Frontend', icon: '⚛️', color: '#61DAFB' },
    { name: 'Node.js', level: 88, category: 'Backend', icon: '🟢', color: '#339933' },
    { name: '.NET / C#', level: 80, category: 'Backend', icon: '🟣', color: '#512BD4' },
    { name: 'REST APIs', level: 90, category: 'Backend', icon: '🔗', color: '#00ffff' },
    { name: 'SQL Server', level: 83, category: 'Data', icon: '🗄️', color: '#CC2927' },
    { name: 'BBPS', level: 92, category: 'Payments', icon: '💳', color: '#ffff00' },
    { name: 'Git / JIRA', level: 86, category: 'Tools', icon: '🔧', color: '#00ff00' },
    { name: 'Slack API', level: 80, category: 'Tools', icon: '💬', color: '#ff00ff' },
    { name: 'WebSockets', level: 75, category: 'Tools', icon: '🔌', color: '#ff8800' }
  ];
}
